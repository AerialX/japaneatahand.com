package com.aerialx.util;

/**
 * Defines a range, from a minimum to maximum
 * @author Aaron Lindsay
 */
public class Range
{

    protected int minimum;
    protected int maximum;

    public Range(int min, int max)
    {
        this.minimum = min;
        this.maximum = max;
    }

    public int getMaximum()
    {
        return maximum;
    }

    public void setMaximum(int val)
    {
        this.maximum = val;
    }

    public int getMinimum()
    {
        return minimum;
    }

    public void setMinimum(int val)
    {
        this.minimum = val;
    }
}


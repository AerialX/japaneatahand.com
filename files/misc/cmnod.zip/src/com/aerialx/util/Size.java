package com.aerialx.util;

/**
 * Holds a size, integer width and height
 * @author Aaron Lindsay
 */
public class Size
{

    protected int width;
    protected int height;

    public Size(int width, int height)
    {
        this.width = width;
        this.height = height;
    }

    public int getHeight()
    {
        return height;
    }

    public void setHeight(int val)
    {
        this.height = val;
    }

    public int getWidth()
    {
        return width;
    }

    public void setWidth(int val)
    {
        this.width = val;
    }
}


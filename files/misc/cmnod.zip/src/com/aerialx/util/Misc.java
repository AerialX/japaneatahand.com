package com.aerialx.util;

import java.io.File;
import java.util.ArrayList;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

/**
 * Holds miscellaneous helper functions
 * @author Aaron Lindsay
 */
public class Misc
{

    public static int round(double i)
    {
        if ((int)i != i)
        {
            return (int)i + 1;
        }
        else
        {
            return (int)i;
        }
    }
    
    public static Animation[] createBattleAnimationsFromSpriteSheet(SpriteSheet sheet, int frameDuration)
    {
        Animation[] animations = new Animation[2];
        
        //First, make a waiting animation from frame 0
        Animation animation = new Animation(true);
        animation.addFrame(sheet.getSprite(0, 0), frameDuration);
        animations[0] = animation;
        
        //Now make an animation consisting of the entire sheet
        animation = new Animation(true);
        for (int y = 0; y < sheet.getVerticalCount(); y++)
        {
            for (int x = 0; x < sheet.getHorizontalCount(); x++)
            {
                animation.addFrame(sheet.getSprite(x, y), frameDuration);
            }
        }
        animations[1] = animation;
        
        return animations;
    }
    
    public static Animation[] createBattleAnimationsFromFolder(String folder, int frameDuration) throws SlickException
    {
        Animation[] animations = new Animation[2];
        
        //First, make a waiting animation from frame 0
        Animation animation = new Animation(true);
        animation.addFrame(new Image(combinePaths(folder, 0)), frameDuration);
        animations[0] = animation;
        
        //Now make an animation consisting of the entire sheet
        animation = new Animation(true);
        
        File directory = new File(folder);
        
        File[] files = directory.listFiles();
        
        for (File file : files)
        {
            animation.addFrame(new Image(file.getPath()), frameDuration);
        }
        animations[1] = animation;
        
        return animations;
    }

    public static float[] toArrayFromFloatList(ArrayList<Float> xDeltas)
    {
        float[] array = new float[xDeltas.size()];
        
        for (int i = 0; i < array.length; i++) {
            array[i] = xDeltas.get(i);
        }

        return array;
    }
    
    private static String combinePaths(String folder, int file)
    {
        if (!folder.endsWith("\\") || !folder.endsWith("/"))
            folder += "/";
        
        String sFile = Integer.toString(file);
        
        if (sFile.length() < 2)
            sFile = "0" + sFile;
        
        sFile += ".png";
        
        return folder + sFile;
    }
}

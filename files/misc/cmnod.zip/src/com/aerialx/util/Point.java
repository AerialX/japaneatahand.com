package com.aerialx.util;

/**
 * Defines one point, integer x and y class.
 * @author Aaron Lindsay
 */
public class Point
{

    protected int x;
    protected int y;

    public Point(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public int getX()
    {
        return x;
    }

    public void setX(int val)
    {
        this.x = val;
    }

    public int getY()
    {
        return y;
    }

    public void setY(int val)
    {
        this.y = val;
    }
    
    public Point getScaledCopy(float scale)
    {
        return new Point((int)(this.x * scale), (int)(this.y * scale));
    }

    @Override
    public int hashCode()
    {
        int hash = 5;
        hash = 59 * hash + this.x;
        hash = 59 * hash + this.y;
        return hash;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof Point)
        {
            Point point = (Point)obj;
            return x == point.getX() && y == point.getY();
        }
        else
            return super.equals(obj);
    }
}


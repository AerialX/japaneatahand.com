package com.aerialx.cmnod.tiles;

import com.aerialx.cmnod.core.Map;
import com.aerialx.cmnod.core.Tile;
import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.util.Point;
import java.util.Random;
import org.newdawn.slick.SpriteSheet;

/**
 *
 * @author Aaron Lindsay
 */
public class Water extends Tile
{
    public static SpriteSheet sheet;
    public static Random random = new Random();
    
    public Water(Map map, Point path, Point position)
    {
        super(map, getSheet().getSprite(path.getX(), path.getY()).getScaledCopy(2F), position, "Water");
        
        movementCosts.put(UnitType.ALL, -1);
    }
    
    public static SpriteSheet getSheet()
    {
        if (sheet == null)
        {
            try
            {
                sheet = new SpriteSheet("res/Tilesets/Water.png", 16, 16);
            } catch (Exception ex) { }
        }
        
        return sheet;
    }
}

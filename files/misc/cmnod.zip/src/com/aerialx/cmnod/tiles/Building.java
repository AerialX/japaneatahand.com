package com.aerialx.cmnod.tiles;

import com.aerialx.cmnod.core.Map;
import com.aerialx.cmnod.core.Tile;
import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.util.Point;
import java.util.Random;
import org.newdawn.slick.SpriteSheet;

/**
 *
 * @author Aaron Lindsay
 */
public class Building
{

    public static SpriteSheet sheet;
    public static Random random = new Random();
    public static final int BUILDING_SMALL1 = 0;
    public static final int BUILDING_SMALL2 = 1;
    public static final int BUILDING_SMALL3 = 2;
    public static final int BUILDING_SMALL4 = 3;
    public static final int BUILDING_LARGE1 = 4;
    public static final int BUILDING_LARGE2 = 5;
    public static final int BUILDING_LARGE3 = 6;

    public static void putBuilding(Map map, Point position, int building)
    {
        if (sheet == null)
            getSheet();
        
        if (building < 4)
        {
            getBuilding(map, position, building);
            return;
        }
        
        int xOffset = 2;
        switch (building)
        {
            case BUILDING_LARGE1:
                xOffset = 2;
                break;
            case BUILDING_LARGE2:
                xOffset = 5;
                break;
            case BUILDING_LARGE3:
                xOffset = 8;
                break;
        }
        
        for (int x = xOffset; x < xOffset + 3; x++)
        {
            for (int y = 0; y < 3; y++)
            {
                Tile tile = new Tile(map, sheet.getSprite(x, y).getScaledCopy(2F), new Point(position.getX() + x - xOffset, position.getY() + y), "Building");
                tile.getMovementCosts().put(UnitType.ALL, -1);
            }
        }
        
        switch (building)
        {
            case BUILDING_LARGE1:
            case BUILDING_LARGE2:
                Tile tile = map.getTile(new Point(position.getX() + 1, position.getY() + 2));
                tile.getMovementCosts().put(UnitType.ALL, 1);
                tile.setName("Path");
                break;
        }
    }
    
    private static Tile getBuilding(Map map, Point position, int building)
    {
        switch (building)
        {
            case BUILDING_SMALL1:
                return new Tile(map, sheet.getSprite(0, 0).getScaledCopy(2F), position, "Building");
            case BUILDING_SMALL2:
                return new Tile(map, sheet.getSprite(0, 1).getScaledCopy(2F), position, "Building");
            case BUILDING_SMALL3:
                return new Tile(map, sheet.getSprite(1, 0).getScaledCopy(2F), position, "Building");
            case BUILDING_SMALL4:
                return new Tile(map, sheet.getSprite(1, 1).getScaledCopy(2F), position, "Building");
            default:
                return null;
        }
    }
    
    public static SpriteSheet getSheet()
    {
        if (sheet == null)
        {
            try
            {
                sheet = new SpriteSheet("res/Tilesets/Buildings.png", 16, 16);
            }
            catch (Exception ex)
            {
            }
        }

        return sheet;
    }
}

package com.aerialx.cmnod.tiles;

import com.aerialx.cmnod.core.Map;
import com.aerialx.cmnod.core.Tile;
import com.aerialx.util.Point;
import java.util.Random;
import org.newdawn.slick.SpriteSheet;

/**
 *
 * @author Aaron Lindsay
 */
public class DarkPath extends Tile
{
    public static SpriteSheet sheet;
    public static Random random = new Random();
    
    public DarkPath(Map map, Point path, Point position)
    {
        super(map, getSheet().getSprite(path.getX(), path.getY()).getScaledCopy(2F), position, "Path");
    }
    
    public static SpriteSheet getSheet()
    {
        if (sheet == null)
        {
            try
            {
                sheet = new SpriteSheet("res/Tilesets/DarkPaths.png", 16, 16);
            } catch (Exception ex) { }
        }
        
        return sheet;
    }
}

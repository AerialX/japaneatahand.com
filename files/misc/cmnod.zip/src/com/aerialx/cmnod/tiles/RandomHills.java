package com.aerialx.cmnod.tiles;

import com.aerialx.cmnod.core.Map;
import com.aerialx.cmnod.core.Tile;
import com.aerialx.cmnod.core.units.UnitStats;
import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.util.Point;
import java.util.Random;
import org.newdawn.slick.Image;
import org.newdawn.slick.SpriteSheet;

/**
 *
 * @author Aaron Lindsay
 */
public class RandomHills extends Tile
{
    public static SpriteSheet sheet;
    public static Random random = new Random();
    
    public RandomHills(Map map, Point position)
    {
        super(map, getRandomTile().getScaledCopy(2F), position, "Hill");
        
        movementCosts.put(UnitType.ALL, 3);
        terrainBonuses.put(UnitType.ALL, new UnitStats(0, 0, 2, 0, 0, 0, 0, 0));
    }
    
    public static SpriteSheet getSheet()
    {
        if (sheet == null)
        {
            try
            {
                sheet = new SpriteSheet("res/Tilesets/Hills.png", 16, 16);
            } catch (Exception ex) { }
        }
        
        return sheet;
    }
    
    public static Image getRandomTile()
    {
        if (sheet == null)
            getSheet();
        
        return sheet.getSprite(random.nextInt(sheet.getWidth() / 16), random.nextInt(sheet.getHeight() / 16));
    }
}

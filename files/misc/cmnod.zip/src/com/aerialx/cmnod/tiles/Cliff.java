package com.aerialx.cmnod.tiles;

import com.aerialx.cmnod.core.Map;
import com.aerialx.cmnod.core.Tile;
import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.util.Point;
import java.util.Random;
import org.newdawn.slick.SpriteSheet;

/**
 *
 * @author Aaron Lindsay
 */
public class Cliff extends Tile
{
    public static SpriteSheet sheet;
    public static Random random = new Random();
    
    public Cliff(Map map, Point cliff, Point position)
    {
        super(map, getSheet().getSprite(cliff.getX(), cliff.getY()).getScaledCopy(2F), position, "Cliff");
        
        movementCosts.put(UnitType.ALL, -1);
    }
    
    public static SpriteSheet getSheet()
    {
        if (sheet == null)
        {
            try
            {
                sheet = new SpriteSheet("res/Tilesets/Cliffs.png", 16, 16);
            } catch (Exception ex) { }
        }
        
        return sheet;
    }
}

package com.aerialx.cmnod.game;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.Map;
import com.aerialx.cmnod.core.Player;
import com.aerialx.cmnod.core.items.WeaponItem;
import com.aerialx.cmnod.core.states.GameState;
import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.cmnod.core.util.tile.AnimatedTileLayer;
import com.aerialx.cmnod.core.util.xml.XmlCharacters;
import com.aerialx.cmnod.core.util.xml.XmlClasses;
import com.aerialx.cmnod.items.Axe;
import com.aerialx.cmnod.items.AxeType;
import com.aerialx.cmnod.items.Sword;
import com.aerialx.cmnod.items.SwordType;
import com.aerialx.cmnod.tiles.Building;
import com.aerialx.cmnod.tiles.LightPath;
import com.aerialx.cmnod.tiles.RandomGrass;
import com.aerialx.cmnod.tiles.RandomTrees;
import com.aerialx.cmnod.units.AssasinCharacter;
import com.aerialx.cmnod.units.BrigandCharacter;
import com.aerialx.util.Point;
import com.aerialx.util.Size;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

/**
 * Sets up our basic map and test setting.
 * @author Aaron
 */
public class InGameState extends GameState
{
    public InGameState()
    {
        super(new Game(new Map(new Size(30, 30), 32)));
    }

    @Override
    public void init(GameContainer container, StateBasedGame sbg) throws SlickException
    {
        super.init(container, sbg);
        
        Map map = game.getMap();
        Size mapSize = map.getSize();
        
        Building.putBuilding(map, new Point(0, 1), Building.BUILDING_LARGE1);
        Building.putBuilding(map, new Point(7, 1), Building.BUILDING_LARGE3);
        Building.putBuilding(map, new Point(14, 1), Building.BUILDING_LARGE1);
        Building.putBuilding(map, new Point(6, 7), Building.BUILDING_LARGE2);
        Building.putBuilding(map, new Point(4, 3), Building.BUILDING_SMALL1);
        Building.putBuilding(map, new Point(12, 3), Building.BUILDING_SMALL1);
        Building.putBuilding(map, new Point(6, 5), Building.BUILDING_SMALL3);
        Building.putBuilding(map, new Point(10, 5), Building.BUILDING_SMALL3);
        
        new LightPath(map, new Point(0, 1), new Point(1, 4));
        new LightPath(map, new Point(5, 4), new Point(2, 4));
        new LightPath(map, new Point(3, 1), new Point(2, 5));
        new LightPath(map, new Point(4, 3), new Point(3, 5));
        new LightPath(map, new Point(4, 2), new Point(3, 4));
        new LightPath(map, new Point(2, 0), new Point(4, 4));
        new LightPath(map, new Point(2, 3), new Point(5, 5));
        new LightPath(map, new Point(3, 0), new Point(5, 4));
        new LightPath(map, new Point(4, 3), new Point(4, 5));
        new LightPath(map, new Point(0, 4), new Point(3, 6));
        new LightPath(map, new Point(2, 4), new Point(4, 6));
        
        new LightPath(map, new Point(2, 1), new Point(15, 4));
        new LightPath(map, new Point(2, 1), new Point(7, 10));
       
        new RandomTrees(map, new Point(9, 6));
        new RandomTrees(map, new Point(10, 6));
        new RandomTrees(map, new Point(11, 6));
        new RandomTrees(map, new Point(9, 7));
        new RandomTrees(map, new Point(10, 7));
        new RandomTrees(map, new Point(11, 7));
        new RandomTrees(map, new Point(9, 8));
        new RandomTrees(map, new Point(10, 8));
        new RandomTrees(map, new Point(11, 8));
        
        //Fill everything else with grass
        AnimatedTileLayer.AnimatedTileModel tiles = map.getTiles();
        for (int x = 0; x < mapSize.getWidth(); x++)
        {
            for (int y = 0; y < mapSize.getHeight(); y++)
            {
                if (tiles.getTile(x, y) == null)
                    new RandomGrass(map, new Point(x, y));
            }
        }
        
        Player player1 = new Player("Player 1", game, Color.green);
        Player player2 = new Player("Player 2", game, Color.red);
        game.getPlayers().add(player1);
        game.getPlayers().add(player2);
        
        Point[] assasinPoints = new Point[] {
            new Point(2, 7),
            new Point(1, 9),
            new Point(5, 8),
            new Point(7, 9),
            new Point(3, 7),
            new Point(0, 10)
        };
        Point[] brigandPoints = new Point[] {
            new Point(14, 8),
            new Point(11, 5),
            new Point(14, 6),
            new Point(12, 7),
            new Point(13, 9),
            new Point(15, 5)
        };
        
        for (int i = 0; i < 6; i++)
        {
            Unit assasin = new Unit(new AssasinCharacter(), assasinPoints[i], player1);
            assasin.getSkills().put(SwordType.INSTANCE, 1);
            WeaponItem sword = new WeaponItem(new Sword());
            assasin.getWeapons().add(sword);
            sword.equip(assasin);
            player1.getUnits().add(assasin);
            units.addActor(assasin);
            
            Unit brigand = new Unit(new BrigandCharacter(), brigandPoints[i], player2);
            brigand.getSkills().put(AxeType.INSTANCE, 1);
            WeaponItem axe = new WeaponItem(new Axe());
            brigand.getWeapons().add(axe);
            axe.equip(brigand);
            player2.getUnits().add(brigand);
            units.addActor(brigand);
        }
        
        game.selectPlayersUnit();
    }
}

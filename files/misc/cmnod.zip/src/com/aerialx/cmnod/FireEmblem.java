package com.aerialx.cmnod;

import com.aerialx.cmnod.core.states.BattleState;
import com.aerialx.cmnod.core.util.xml.XmlClasses;
import com.aerialx.cmnod.game.InGameState;
import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.util.Log;

/**
 * The base game class that sets everything in motion.
 * @author Aaron Lindsay
 */
public class FireEmblem extends StateBasedGame
{
    public static final String GAME_NAME = "CMNOD";
    protected InGameState ingame = new InGameState();
    protected BattleState battle;
    protected AppGameContainer container;

    public FireEmblem()
    {
        super(GAME_NAME);
        
        battle = new BattleState(ingame.getGame());
    }

    public void initStatesList(GameContainer container) throws SlickException
    {
        if (container instanceof AppGameContainer)
        {
            this.container = (AppGameContainer)container;
            
            container.getInput().enableKeyRepeat(600, 100);
        }
        container.setVSync(false);
        container.setShowFPS(false);
        container.setMinimumLogicUpdateInterval(10);
        container.setMaximumLogicUpdateInterval(10);
        addState(ingame);
        addState(battle);
    }

    @Override
    public void keyPressed(int key, char c)
    {
        super.keyPressed(key, c);

        if (key == Input.KEY_F2)
        {
            if (container != null)
            {
                try
                {
                    container.setFullscreen(!container.isFullscreen());
                }
                catch (SlickException e)
                {
                    Log.error(e);
                }
            }
        }
    }

    public InGameState getIngame()
    {
        return ingame;
    }

    /**
     * Entry point of the application, starts a new game of CMNOD
     * @param argv
     */
    public static void main(String[] argv)
    {
        System.out.println("Be patient as the game loads...");
        
        try
        {
            AppGameContainer container = new AppGameContainer(new FireEmblem());
            container.setDisplayMode(640, 480, false);
            container.start();
        }
        catch (SlickException e)
        {
            e.printStackTrace();
        }
    }
}

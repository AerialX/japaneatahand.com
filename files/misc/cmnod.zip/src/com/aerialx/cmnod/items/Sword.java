package com.aerialx.cmnod.items;

import com.aerialx.cmnod.core.items.Weapon;
import com.aerialx.cmnod.core.items.WeaponStats;
import com.aerialx.util.Range;

/**
 *
 * @author Aaron Lindsay
 */
public class Sword extends Weapon
{

    public Sword()
    {
        super("Sword", "It slices! Ow!", SwordType.INSTANCE, new WeaponStats(1, 1, 45, 1, 1, new Range(1, 1)), 0, 5);
    }
}

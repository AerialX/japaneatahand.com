package com.aerialx.cmnod.items;

import com.aerialx.cmnod.core.items.WeaponType;

/**
 *
 * @author Aaron Lindsay
 */
public class AxeType extends WeaponType
{
    public static final AxeType INSTANCE = new AxeType();
    
    public AxeType()
    {
        super("Axe", false, null, null);
    }
}

package com.aerialx.cmnod.items;

import com.aerialx.cmnod.core.items.WeaponType;

/**
 *
 * @author Aaron Lindsay
 */
public class LanceType extends WeaponType
{
    public static final LanceType INSTANCE = new LanceType();
    
    public LanceType()
    {
        super("Lance", false, null, null);
    }
}

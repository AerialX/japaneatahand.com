package com.aerialx.cmnod.items;

import com.aerialx.cmnod.core.items.WeaponType;

/**
 *
 * @author Aaron Lindsay
 */
public class SwordType extends WeaponType
{
    public static final SwordType INSTANCE = new SwordType();
    
    public SwordType()
    {
        super("Sword", false, null, null);
    }
}

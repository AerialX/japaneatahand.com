package com.aerialx.cmnod.units;

import com.aerialx.cmnod.core.units.UnitClass;
import com.aerialx.cmnod.core.units.UnitStats;

/**
 *
 * @author Aaron Lindsay
 */
public class Brigand extends UnitClass {
    public static final UnitStats STATS = new UnitStats(7, 5, 1, 0, 0, 5, 5, 5);
    public static final UnitStats LEVELUP = new UnitStats(2, 5, 4, 0, 4, 1, 2, 80);
    
    public Brigand()
    {
        super("Brigand", GroundUnit.INSTANCE, 7, STATS, LEVELUP, 1F / 5);
    }
}

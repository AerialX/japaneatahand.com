package com.aerialx.cmnod.units;

import com.aerialx.cmnod.core.units.Character;
import com.aerialx.cmnod.core.util.NlrudAnimationSelector;
import com.aerialx.util.Misc;
import com.aerialx.util.Point;
import com.aerialx.util.Size;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

/**
 *
 * @author Aaron Lindsay
 */
public class BrigandCharacter extends Character {
    public BrigandCharacter() throws SlickException
    {
        super(new Brigand(),
            "That Brigand",
            NlrudAnimationSelector.splitUpSpriteSheet(
                new SpriteSheet(new Image("res/Sprites/BrigandMapX2.png"), 27*2, 27*2), new Image("res/Sprites/BrigandMapDisabled.png"), 3, 3, 3, 3, 3
            ),
            //Misc.createBattleAnimationsFromSpriteSheet(new SpriteSheet(new BigImage("res/Sprites/AssasinBattle.png"), 60, 43), 10),
            Misc.createBattleAnimationsFromFolder("res/Sprites/BrigandBattleX2", 130),
            new float[] { 1, 1, 1, 1, 0.6F, 0.2F, -0.2F, -0.2F, -0.2F, 0.4F, 1, 1 },
            6,
            new Size(42*2, 74*2)
        );
        
        this.offset = new Point(20, -60);
    }
}

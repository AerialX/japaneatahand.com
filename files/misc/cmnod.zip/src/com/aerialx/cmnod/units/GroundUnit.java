package com.aerialx.cmnod.units;

import com.aerialx.cmnod.core.units.UnitType;

/**
 *
 * @author Aaron Lindsay
 */
public class GroundUnit extends UnitType {
    public static final GroundUnit INSTANCE = new GroundUnit();
    
    public GroundUnit()
    {
        super("Ground");
    }
}

package com.aerialx.cmnod.units;

import com.aerialx.cmnod.core.units.Character;
import com.aerialx.cmnod.core.util.NlrudAnimationSelector;
import com.aerialx.util.Misc;
import com.aerialx.util.Size;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;

/**
 *
 * @author Aaron Lindsay
 */
public class AssasinCharacter extends Character {
    public AssasinCharacter() throws SlickException
    {
        super(new Assasin(),
            "That Assasin",
            NlrudAnimationSelector.splitUpSpriteSheet(
                new SpriteSheet(new Image("res/Sprites/AssasinMapX2.png"), 19*2, 19*2), new Image("res/Sprites/AssasinMapDisabled.png"), 3, 3, 3, 4, 4
            ),
            //Misc.createBattleAnimationsFromSpriteSheet(new SpriteSheet(new BigImage("res/Sprites/AssasinBattle.png"), 60, 43), 10),
            Misc.createBattleAnimationsFromFolder("res/Sprites/AssasinBattleX2", 80),
            new float[] { 1, 1, 1, 1, 1, 1, 0.8F, 0.6F, 0.4F, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4F, 0.5F, 0.6F, 1, 1, 1, 1, 1, 1, 1, 1 },
            10,
            new Size(60*2, 43*2)
        );
    }
}

package com.aerialx.cmnod.core.states;

import com.aerialx.cmnod.core.Game;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

/**
 * A state that shows information about the map. Currently unused.
 * @author Aaron Lindsay
 */
public class ViewMapState extends BaseState
{
    public ViewMapState(Game game)
    {
        super(game);
    }

    public static final int ID = 3;
    
    public int getID()
    {
        return ViewMapState.ID;
    }

    public void render(GameContainer container, StateBasedGame game, Graphics g) throws SlickException
    {
        
    }

    public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException
    {
        
    }
}

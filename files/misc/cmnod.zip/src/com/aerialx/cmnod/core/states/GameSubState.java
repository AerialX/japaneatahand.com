package com.aerialx.cmnod.core.states;

/**
 * A GameSubState is used in conjunction with StateInputActors to specify which
 * Actor or UI element gets input
 * @author Aaron Lindsay
 */
public class GameSubState
{

    protected String name;

    public GameSubState(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}

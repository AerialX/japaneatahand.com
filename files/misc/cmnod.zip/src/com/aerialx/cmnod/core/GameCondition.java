package com.aerialx.cmnod.core;

public interface GameCondition
{

    public int getWinner();
}


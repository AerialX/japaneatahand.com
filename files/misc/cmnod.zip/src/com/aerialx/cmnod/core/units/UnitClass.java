package com.aerialx.cmnod.core.units;

/**
 * A generic class for a unit's classification.
 * @author Aaron Lindsay
 */
public class UnitClass
{
    protected UnitType unitType;
    protected String className;
    protected UnitStats baseStats;
    protected UnitStats levelup;
    protected int movement;
    protected float movementSpeed;

    public UnitClass(String name, UnitType type, int movement, UnitStats stats, UnitStats levelup, float movementSpeed)
    {
        this.className = name;
        this.unitType = type;
        this.baseStats = stats;
        this.levelup = levelup;
        this.movement = movement;
        this.movementSpeed = movementSpeed;
    }

    public float getMovementSpeed()
    {
        return movementSpeed;
    }

    public void setMovementSpeed(float movementSpeed)
    {
        this.movementSpeed = movementSpeed;
    }
    
    public int getMovement()
    {
        return movement;
    }

    public void setMovement(int movement)
    {
        this.movement = movement;
    }
    
    public UnitStats getBaseStats()
    {
        return baseStats;
    }

    public void setBaseStats(UnitStats val)
    {
        this.baseStats = val;
    }

    public String getClassName()
    {
        return className;
    }

    public void setClassName(String val)
    {
        this.className = val;
    }

    public UnitStats getLevelup()
    {
        return levelup;
    }

    public void setLevelup(UnitStats val)
    {
        this.levelup = val;
    }

    public UnitType getUnitType()
    {
        return unitType;
    }

    public void setUnitType(UnitType val)
    {
        this.unitType = val;
    }
}


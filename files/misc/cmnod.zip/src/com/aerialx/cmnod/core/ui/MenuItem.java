package com.aerialx.cmnod.core.ui;

/**
 * An item as part of a menu
 * @author Aaron Lindsay
 */
public abstract class MenuItem
{
    protected AbstractMenu menu;
    protected String name;
    protected String description;

    public MenuItem(AbstractMenu menu, String name, String description)
    {
        this.menu = menu;
        this.name = name;
        this.description = description;
    }
    
    public abstract void select();
    
    public void hover()
    {
        
    }

    public void unHover()
    {
        
    }
    
    public AbstractMenu getMenu()
    {
        return menu;
    }
    
    public String getDescription()
    {
        return description;
    }

    public String getName()
    {
        return name;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public void setName(String name)
    {
        this.name = name;
    }
}

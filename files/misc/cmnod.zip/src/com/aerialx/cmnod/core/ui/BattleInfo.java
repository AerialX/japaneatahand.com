/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.aerialx.cmnod.core.ui;

import com.aerialx.cmnod.core.states.GameState;
import com.slickset.Actor;
import org.newdawn.slick.state.StateBasedGame;

/**
 * Unused.
 * @author Aaron Lindsay
 */
public class BattleInfo extends Actor {

    protected GameState state;
    
    public BattleInfo(GameState state)
    {
        super(state.getStateBasedGame().getContainer().getWidth() - 10 - 100, 70);
        
        this.state = state;
    }

    @Override
    public void update(StateBasedGame game, int delta)
    {
        super.update(game, delta);
        
        if (state.getCursor().getTask() == Cursor.TASK_ATTACKUNIT)
        {
            
        }
    }
}

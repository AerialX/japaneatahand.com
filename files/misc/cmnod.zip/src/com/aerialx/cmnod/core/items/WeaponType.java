package com.aerialx.cmnod.core.items;

import org.newdawn.slick.Image;

/**
 * Represents a generic type of weapon. The typical are: Sword, Lance, Axe, and Bow
 * @author Aaron Lindsay
 */
public class WeaponType
{

    protected Image icon;
    protected String name;
    protected boolean magic;
    protected Weapon weakness;

    public WeaponType(String name, boolean magic, Weapon weakness, Image icon)
    {
        this.name = name;
        this.magic = magic;
        this.weakness = weakness;
        this.icon = icon;
    }

    public Image getIcon()
    {
        return icon;
    }

    public void setIcon(Image val)
    {
        this.icon = val;
    }

    public boolean getMagic()
    {
        return magic;
    }

    public void setMagic(boolean val)
    {
        this.magic = val;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String val)
    {
        this.name = val;
    }

    public Weapon getWeakness()
    {
        return weakness;
    }

    public void setWeakness(Weapon val)
    {
        this.weakness = val;
    }
}


package com.aerialx.cmnod.core.units;

import com.aerialx.cmnod.core.util.NlrudAnimationSelector;
import com.aerialx.util.Point;
import com.aerialx.util.Size;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Image;

/**
 * All stats of a unit are stored as a character
 * @author Aaron Lindsay
 */
public class Character
{
    protected UnitClass unitClass;
    protected String name;
    protected Animation[] mapAnimations;
    protected Animation[] battleAnimations;
    protected float[] battleXdelta;
    protected int attackFrame;
    protected Point offset;
    protected Size size;
    
    public Character(UnitClass unitClass, String name, Animation[] mapAnimations, Animation[] battleAnimations, float[] battleXdelta, int attackFrame, Size size)
    {
        this.unitClass = unitClass;
        this.name = name;
        this.mapAnimations = mapAnimations;
        this.battleAnimations = battleAnimations;
        this.battleXdelta = battleXdelta;
        this.attackFrame = attackFrame;
        this.size = size;
        
        this.offset = new Point(0, 0);
    }
    
    public UnitStats getUnitStats()
    {
        return unitClass.getBaseStats();
    }
    
    public float getMovementSpeed()
    {
        return unitClass.getMovementSpeed();
    }

    public Point getOffset()
    {
        return offset;
    }
    
    public int getMovement()
    {
        return unitClass.getMovement();
    }
    
    public Animation getMapAnimations(int direction, int status)
    {
        return mapAnimations[getMapAnimationIndex(direction, status)];
    }
    
    public int getMapAnimationIndex(int direction, int status)
    {
        //Defaults to my NLRUD (Neutral, Left, Right, Up, Down) format
        return NlrudAnimationSelector.getAnimation(direction, status);
    }

    public int getAttackFrame()
    {
        return attackFrame;
    }
    
    public float[] getBattleXdelta()
    {
        return battleXdelta;
    }

    public Animation[] getMapAnimations()
    {
        //return mapAnimations;
        Animation[] returnAnimations = new Animation[mapAnimations.length];
        
        for (int i = 0; i < returnAnimations.length; i++)
        {
            Animation animation = mapAnimations[i];
            Animation newAnimation = new Animation(true);
            
            for (int j = 0; j < animation.getFrameCount(); j++)
            {
                Image image = animation.getImage(j);
                newAnimation.addFrame(image, animation.getDuration(j));
            }

            returnAnimations[i] = newAnimation;
        }
        
        return returnAnimations;
    }
    
    public Animation[] getBattleAnimations()
    {
        return battleAnimations;
    }

    public void setMapAnimations(Animation[] animations)
    {
        this.mapAnimations = animations;
    }

    public Size getSize()
    {
        return size;
    }

    public void setSize(Size size)
    {
        this.size = size;
    }
    
    public UnitClass getUnitClass()
    {
        return unitClass;
    }

    public void setUnitClass(UnitClass unitClass)
    {
        this.unitClass = unitClass;
    }
    
    public String getName()
    {
        return name;
    }

    public void setName(String val)
    {
        this.name = val;
    }
}


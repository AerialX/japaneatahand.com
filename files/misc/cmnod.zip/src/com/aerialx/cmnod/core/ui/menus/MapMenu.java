package com.aerialx.cmnod.core.ui.menus;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.states.BaseState;
import com.aerialx.cmnod.core.states.GameSubState;
import com.aerialx.cmnod.core.ui.AbstractMenu;
import com.aerialx.cmnod.core.ui.MenuItem;
import com.aerialx.util.Point;
import com.aerialx.util.Size;

/**
 * A menu that gives you some general options and you can end your turn.
 * @author Aaron Lindsay
 */
public class MapMenu extends AbstractMenu
{

    public static final GameSubState GAME_SUBSTATE = new GameSubState("MapMenu");

    public MapMenu(Point position, BaseState state, Game game)
    {
        super(position, new Size(128, 24), state, game, MapMenu.GAME_SUBSTATE);
        
        //getItems().add(new ViewMap(this));
        //getItems().add(new Statistics(this));
        getItems().add(new EndTurn(this));
        getItems().add(new Cancel(this));
    }

    public class ViewMap extends MenuItem
    {

        public ViewMap(AbstractMenu menu)
        {
            super(menu, "View Map", "Shows detailed information about the map.");
        }

        public void select()
        {
            //getMenu().getGame().toViewMap();
        }
    }
    
    public class Statistics extends MenuItem
    {
        public Statistics(AbstractMenu menu)
        {
            super(menu, "Player Statistics", "Shows detailed information about the current player.");
        }

        public void select()
        {
            //menu.getGame().toPlayerStatistics(menu.getGame().getCurrentPlayer());
        }
    }
    
    public class EndTurn extends MenuItem
    {
        public EndTurn(AbstractMenu menu)
        {
            super(menu, "End Turn", "Ends the current player's turn.");
        }

        public void select()
        {
            menu.hide();
            menu.getGame().changeTurn();
        }
    }
    
    public class Cancel extends MenuItem
    {
        public Cancel(AbstractMenu menu)
        {
            super(menu, "Cancel", "Closes the menu without doing anything.");
        }

        public void select()
        {
            menu.hide();
        }
    }
}

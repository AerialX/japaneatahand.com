package com.aerialx.cmnod.core;

import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.cmnod.core.items.WeaponType;
import com.aerialx.cmnod.core.states.BattleState;
import com.aerialx.cmnod.core.states.GameState;
import com.aerialx.cmnod.core.states.PlayerStatsState;
import com.aerialx.cmnod.core.states.ViewMapState;
import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.util.Point;
import java.util.ArrayList;
import java.util.Hashtable;
import org.newdawn.slick.Color;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

/**
 * Holds all the information about one game
 * @author Aaron Lindsay
 */
public class Game
{

    protected BattleState battleState;
    protected GameState gameState;
    protected ViewMapState viewMapState;
    protected PlayerStatsState playerStatsState;
    protected Map map;
    protected ArrayList<Player> players;
    protected int turn;
    protected int playerTurn;
    protected GameCondition winCondition;
    protected Hashtable<String, UnitType> unitTypes;
    protected Hashtable<String, WeaponType> weaponTypes;
    protected Point position;
    public static final int TRANSITION_DELAY = 300;

    public Game(Map map)
    {
        this.map = map;
        map.setGame(this);
        
        this.turn = 0;
        this.playerTurn = 0;
        this.players = new ArrayList<Player>();
        this.weaponTypes = new Hashtable<String, WeaponType>();
        this.unitTypes = new Hashtable<String, UnitType>();
    }

    public void changeTurn()
    {
        playerTurn++;
        playerTurn %= players.size();
        
        getCurrentPlayer().playerTurn();
        
        gameState.notifyTurnOver();
        
        clearUnitStatus();
        
        selectPlayersUnit();
    }
    
    public void selectPlayersUnit()
    {
        Player player = getCurrentPlayer();
        
        if (player.getUnits().size() > 0)
        {
            Unit unit = player.getUnits().get(0);
            
            gameState.getCursor().setDestination(unit.getPosition());
            gameState.cursorHoverSpace(gameState.getCursor().getDestination());
        }
    }
    
    public void clearUnitStatus()
    {
        for (Player player : players)
        {
            for (Unit unit : player.getUnits())
            {
                if (unit.getStatus() == Unit.UNUSABLE)
                    unit.setStatus(Unit.USABLE);
            }

        }

    }
    
    public void toBattle(Unit attacker, Unit attackee)
    {
        battleState.beginBattle(attacker, attackee);
        gameState.getStateBasedGame().enterState(battleState.getID(), new FadeOutTransition(Color.black, TRANSITION_DELAY), new FadeInTransition(Color.black, TRANSITION_DELAY));
    }
    
    public void toMapView()
    {
        gameState.checkForEndOfTurn();
        gameState.cursorHoverSpace(gameState.getCursor().getDestination());
        gameState.getStateBasedGame().enterState(gameState.getID(), new FadeOutTransition(Color.black, TRANSITION_DELAY), new FadeInTransition(Color.black, TRANSITION_DELAY));
    }
    
    public void toViewMap()
    {
        gameState.getStateBasedGame().enterState(viewMapState.getID(), new FadeOutTransition(Color.black, TRANSITION_DELAY), new FadeInTransition(Color.black, TRANSITION_DELAY));
    }
    
    public void toPlayerStatistics(Player player)
    {
        playerStatsState.setPlayer(player);
        gameState.getStateBasedGame().enterState(viewMapState.getID(), new FadeOutTransition(Color.black, TRANSITION_DELAY), new FadeInTransition(Color.black, TRANSITION_DELAY));
    }
    
    public Player getCurrentPlayer()
    {
        return players.get(playerTurn);
    }
    
    public BattleState getBattleState()
    {
        return battleState;
    }

    public void setBattleState(BattleState battleState)
    {
        this.battleState = battleState;
    }

    public GameState getGameState()
    {
        return gameState;
    }

    public void setGameState(GameState gameState)
    {
        this.gameState = gameState;
    }

    public Map getMap()
    {
        return map;
    }

    public void setMap(Map val)
    {
        this.map = val;
    }

    public int getPlayerTurn()
    {
        return playerTurn;
    }

    public void setPlayerTurn(int val)
    {
        this.playerTurn = val;
    }

    public ArrayList<Player> getPlayers()
    {
        return players;
    }

    public void setPlayers(ArrayList<Player> val)
    {
        this.players = val;
    }

    public int getTurn()
    {
        return turn;
    }

    public void setTurn(int val)
    {
        this.turn = val;
    }

    public Hashtable<String, UnitType> getUnitTypes()
    {
        return unitTypes;
    }

    public void setUnitTypes(Hashtable<String, UnitType> val)
    {
        this.unitTypes = val;
    }

    public Hashtable<String, WeaponType> getWeaponTypes()
    {
        return weaponTypes;
    }

    public void setWeaponTypes(Hashtable<String, WeaponType> val)
    {
        this.weaponTypes = val;
    }

    public GameCondition getWinCondition()
    {
        return winCondition;
    }

    public void setWinCondition(GameCondition val)
    {
        this.winCondition = val;
    }
}


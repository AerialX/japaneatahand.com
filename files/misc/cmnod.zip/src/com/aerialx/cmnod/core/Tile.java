package com.aerialx.cmnod.core;

import com.aerialx.cmnod.core.units.UnitStats;
import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.cmnod.core.util.tile.AnimatedTile;
import com.aerialx.util.Point;
import java.util.Hashtable;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Image;

/**
 * Represents one tile on the map
 * @author Aaron Lindsay
 */
public class Tile extends AnimatedTile
{

    protected Map map;
    protected Point position;
    protected String name;
    protected Hashtable<UnitType, Integer> movementCosts;
    protected Hashtable<UnitType, UnitStats> terrainBonuses;

    public Tile(Map map, Image image, Point position, String name)
    {
        this(map, new Animation(new Image[] { image }, Integer.MAX_VALUE), position, name);
    }
    
    public Tile(Map map, Animation animation, Point position, String name)
    {
        this(map, new Animation[] { animation }, position, name);
    }
    
    public Tile(Map map, Animation[] animations, Point position, String name)
    {
        super(animations, map.getTileSize());
        
        this.map = map;
        this.position = position;
        this.name = name;
        
        this.movementCosts = new Hashtable<UnitType, Integer>();
        this.terrainBonuses = new Hashtable<UnitType, UnitStats>();
        this.movementCosts.put(UnitType.ALL, 1);
        this.terrainBonuses.put(UnitType.ALL, new UnitStats());
        
        map.getTiles().setTile(this, position.getX(), position.getY());
    }

    public UnitStats getTerrainBonus(UnitType unit)
    {
        if (terrainBonuses.containsKey(unit))
            return terrainBonuses.get(unit);
        
        return terrainBonuses.get(UnitType.ALL);
    }
    
    public int getMovementCost(UnitType unit)
    {
        if (movementCosts.containsKey(unit))
            return movementCosts.get(unit);
        
        return movementCosts.get(UnitType.ALL);
    }
    
    public Map getMap()
    {
        return map;
    }

    public void setMap(Map val)
    {
        this.map = val;
    }

    public Hashtable<UnitType, Integer> getMovementCosts()
    {
        return movementCosts;
    }

    public void setMovementCosts(Hashtable<UnitType, Integer> val)
    {
        this.movementCosts = val;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String val)
    {
        this.name = val;
    }

    public Point getPosition()
    {
        return position;
    }

    public void setPosition(Point val)
    {
        this.position = val;
    }
}


package com.aerialx.cmnod.core.items;

import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.util.Range;

/**
 * Helper abstract class for an item that can be 'used'
 * @author Aaron Lindsay
 */
public abstract class UsableItem extends Item
{

    protected Range range;

    public UsableItem(String name, String description)
    {
        super(name, description);
    }

    public Range getRange()
    {
        return range;
    }

    public void setRange(Range val)
    {
        this.range = val;
    }

    public abstract void use(Unit unit);
}


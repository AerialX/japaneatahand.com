package com.aerialx.cmnod.core.items;

/**
 * Holds information about one weapon.
 * @author Aaron Lindsay
 */
public class Weapon
{
    protected String name;
    protected String description;
    protected WeaponType type;
    protected int minSkill;
    protected WeaponStats stats;
    protected int maxUses;

    public Weapon(String name, String description, WeaponType type, WeaponStats stats, int minSkill, int maxUses)
    {
        this.name = name;
        this.description = description;
        this.type = type;
        this.stats = stats;
        this.minSkill = minSkill;
        this.maxUses = maxUses;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }
    
    public int getMaxUses()
    {
        return maxUses;
    }

    public void setMaxUses(int val)
    {
        this.maxUses = val;
    }

    public int getMinSkill()
    {
        return minSkill;
    }

    public void setMinSkill(int val)
    {
        this.minSkill = val;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public WeaponStats getStats()
    {
        return stats;
    }

    public void setStats(WeaponStats val)
    {
        this.stats = val;
    }

    public WeaponType getType()
    {
        return type;
    }

    public void setType(WeaponType val)
    {
        this.type = val;
    }
}


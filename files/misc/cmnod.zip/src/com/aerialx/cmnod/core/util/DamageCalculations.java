package com.aerialx.cmnod.core.util;

import com.aerialx.cmnod.core.items.WeaponStats;
import com.aerialx.cmnod.core.units.UnitStats;

/**
 * Does calculations for battles between two units
 * @author Aaron Lindsay
 */
public class DamageCalculations
{

    public DamageCalculations()
    {
    }
    
    public static int calculateStrength(UnitStats attacker, WeaponStats attackerWeapon)
    {
        return attacker.getStrength() + attackerWeapon.getMight();
    }
    
    public static int calculateHitPercentage(UnitStats attacker, UnitStats attackee, WeaponStats attackerWeapon)
    {
        return attacker.getSkill() * 2 + attackerWeapon.getHit() - calculateAvoid(attackee) + attackerWeapon.getHit();
    }
    
    public static int calculateAvoid(UnitStats stats)
    {
        return stats.getSkill() * 2 + stats.getLuck();
    }
    
    public static int calculateSpeed(UnitStats stats, WeaponStats weapon)
    {
        return stats.getSpeed() - 2 * (stats.getStrength() - weapon.getWeight());
    }
    
    public static int calculateCriticalPercentage(UnitStats attacker, WeaponStats attackerWeapon, UnitStats attackee)
    {
        return attacker.getSkill() * 2 + attackerWeapon.getCritical() - attackee.getLuck();
    }
    
    public static int calculateHitTimes(UnitStats attacker, WeaponStats attackerWeapon, UnitStats attackee, WeaponStats attackeeWeapon)
    {
        return calculateHitTimes(calculateSpeed(attacker, attackerWeapon), calculateSpeed(attackee, attackeeWeapon));
    }
    
    public static int calculateHitTimes(int attackerSpeed, int attackeeSpeed)
    {
        return (attackerSpeed - attackeeSpeed >= 4 ? 2 : 1);
    }
}


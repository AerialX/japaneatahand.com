package com.aerialx.cmnod.core.ui;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.states.BaseState;
import com.aerialx.cmnod.core.states.GameSubState;
import com.aerialx.cmnod.core.states.StateInputActor;
import com.aerialx.util.Misc;
import com.aerialx.util.Point;
import com.aerialx.util.Size;
import java.util.ArrayList;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.state.StateBasedGame;

/**
 * A menu for use in the UI on the map. Needs to have items added to it to function.
 * @author Aaron Lindsay
 */
public class AbstractMenu extends StateInputActor
{

    protected int columns;
    protected Point position;
    protected ArrayList<MenuItem> items;
    protected int selectedItem;
    protected Size itemSize;
    protected BaseState state;
    protected MenuListener listener;
    
    public static final int KEY_UP = Input.KEY_UP;
    public static final int KEY_DOWN = Input.KEY_DOWN;
    public static final int KEY_LEFT = Input.KEY_LEFT;
    public static final int KEY_RIGHT = Input.KEY_RIGHT;
    public static final int KEY_SELECT = Input.KEY_SPACE;
    
    public AbstractMenu(Point position, Size itemSize, BaseState state, Game game, GameSubState subState)
    {
        this(position, itemSize, 1, state, game, subState);
    }
    
    public AbstractMenu(Point position, Size itemSize, int columns, BaseState state, Game game, GameSubState subState)
    {
        super((float)position.getX(), (float)position.getY(), game, game.getGameState(), subState);
        
        this.state = state;
        this.position = position;
        this.itemSize = itemSize;
        this.columns = columns;
        
        this.items = new ArrayList<MenuItem>();
        this.selectedItem = -1;
        this.listener = new MenuListener(this);
    }

    public void show()
    {
        state.getMenus().addActor(this);
        this.takeFocus();
        game.getGameState().getStateBasedGame().getContainer().getInput().addListener(listener);
    }
    
    public void hide()
    {
        state.getMenus().removeActor(this);
        this.releiveFocus();
        game.getGameState().getStateBasedGame().getContainer().getInput().removeListener(listener);
    }
    
    public boolean isShown()
    {
        return state.getMenus().getActors().contains(this);
    }
    
    public void render(Graphics g)
    {
        for (MenuItem menuItem : items)
        {
            renderItem(g, menuItem, getSelectedItem() == menuItem);
        }
    }
    
    public void renderItem(Graphics g, MenuItem item, boolean selected)
    {
        int width = itemSize.getWidth();
        int height = itemSize.getHeight();
        float x = getScreenX() + (items.indexOf(item) % getColumns()) * width;
        float y = getScreenY() + (items.indexOf(item) % getRows()) * height;
        
        Color colour;
        
        if (selected)
            colour = new Color(0, 40, 255, 210);
        else
            colour = new Color(0, 0, 255, 150);
        g.setColor(colour);
        g.fillRect(x, y, width, height);
        
        g.setColor(Color.black);
        g.setLineWidth(1);
        g.drawRect(x, y, width, height);
        
        g.setColor(Color.white);
        g.drawString(item.getName(), x + 4, y + 2);
    }
    
    //Translate from world to screen coordinates.
	public float getScreenX()
	{
		return getClipper().getX() + getX() - getLayer().getViewport().getX();
	}
	
	public float getScreenY()
	{
		return getClipper().getY() + getY() - getLayer().getViewport().getY();
	}
    
    private Rectangle getClipper()
    {
        return gameState.getScene().getLayer().getViewport().getClip();
    }
    
    public Point getItemPosition(MenuItem item)
    {
        return getItemPosition(items.indexOf(item));
    }
    
    public Point getItemPosition(int item)
    {
        return new Point((item % getColumns()) * itemSize.getWidth(), (item % getRows()) * itemSize.getHeight());
    }
    
    public void selectItem()
    {
        if (getSelectedIndex() == -1)
            selectDown();
        
        getSelectedItem().select();
    }
    
    public boolean selectUp()
    {
        int currentRow = getSelectedPosition().getY();
        int oldIndex = selectedItem;
        
        if (currentRow > 0)
        {
            if (selectedItem == -1)
                selectedItem = items.size() - 1;
            else
                selectedItem -= getColumns();
            
            notifySelectedItem(oldIndex);
            
            return true;
        }
        else
            return false;
    }
    
    public boolean selectDown()
    {
        int currentRow = getSelectedPosition().getY();
        int rows = getRows() - 1;
        int oldIndex = selectedItem;
        
        if (currentRow < rows)
        {
            selectedItem += getColumns();
            
            notifySelectedItem(oldIndex);
            
            return true;
        }
        else
            return false;
    }
    
    public boolean selectLeft()
    {
        int currentColumn = getSelectedPosition().getX();
        int oldIndex = selectedItem;
        
        if (currentColumn > 0)
        {
            selectedItem -= getRows();
            
            notifySelectedItem(oldIndex);
            
            return true;
        }
        else
            return false;
    }
    
    public boolean selectRight()
    {
        int currentColumn = getSelectedPosition().getX();
        int rows = getRows();
        int oldIndex = selectedItem;
        
        if (currentColumn < rows - 1)
        {
            if (selectedItem == -1)
                selectedItem = rows * getColumns() - 1;
            else
                selectedItem += rows;
            
            notifySelectedItem(oldIndex);
            
            return true;
        }
        else
            return false;
    }
    
    public int getColumns()
    {
        if (items.size() < columns)
            return items.size();
        else
            return columns;
    }

    public void notifySelectedItem(int oldIndex)
    {
        if (oldIndex == selectedItem)
            return;
        
        if (oldIndex >= 0 && oldIndex <= items.size())
            items.get(oldIndex).unHover();
        
        getSelectedItem().hover();
    }
    
    public void handleInput(StateBasedGame game, int delta)
    {
        
    }
    
    public Size getItemSize()
    {
        return itemSize;
    }

    public void setItemSize(Size itemSize)
    {
        this.itemSize = itemSize;
    }
    
    public int getRows()
    {
        return Misc.round((float)items.size() / (float)columns);
    }
    
    public Point getSelectedPosition()
    {
        return new Point(selectedItem % columns, Misc.round((float)selectedItem / (float)columns));
    }
    
    public int getSelectedIndex()
    {
        return selectedItem;
    }

    public void setSelectedItem(int selectedItem)
    {
        int oldIndex = this.selectedItem;
        this.selectedItem = selectedItem;
        
        notifySelectedItem(oldIndex);
    }
    
    public MenuItem getSelectedItem()
    {
        if (selectedItem == -1)
            return null;
        else
            return items.get(selectedItem);
    }
    
    public ArrayList getItems()
    {
        return items;
    }

    public BaseState getState()
    {
        return state;
    }
}

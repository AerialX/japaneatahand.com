package com.aerialx.cmnod.core.items;

import com.aerialx.cmnod.core.units.Unit;

/**
 * An equippable item is an item that can be equipped to a unit, such as a weapon.
 * @author lindaaro242
 */
public abstract class EquippableItem extends Item
{

    public EquippableItem(String name, String description)
    {
        super(name, description);
    }
    
    public abstract boolean canEquip(Unit unit);
    
    public boolean equip(Unit unit)
    {
        if (!canEquip(unit))
            return false;
        
        return unit.getEquippedItems().add(this);
    }
    
    public boolean unequip(Unit unit)
    {
        return unit.getEquippedItems().remove(this);
    }
}


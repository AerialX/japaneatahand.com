/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aerialx.cmnod.core.util;

import com.aerialx.cmnod.core.items.WeaponStats;
import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.cmnod.core.units.UnitStats;

/**
 * Holds stats about an attack during battle
 * @author Aaron Lindsay
 */
public class BattleStats
{
    protected Unit unit;
    protected int hitPercentage;
    protected int criticalPercentage;
    protected int avoid;
    protected int speed;
    protected int strength;
    protected int hitTimes;
    
    public BattleStats(Unit unit)
    {
        this(unit, 0, 0, 0, 0, 0, 0);
    }
    
    public BattleStats(Unit unit, int hitPercentage, int criticalPercentage, int avoid, int speed, int strength, int hitTimes)
    {
        this.unit = unit;
        this.hitPercentage = hitPercentage;
        this.criticalPercentage = criticalPercentage;
        this.avoid = avoid;
        this.speed = speed;
        this.strength = strength;
        this.hitTimes = hitTimes;
    }

    public static BattleStats generateStats(Unit attacker, Unit attackee)
    {
        UnitStats attackerStats = attacker.getCombinedStats();
        UnitStats attackeeStats = attackee.getCombinedStats();
        WeaponStats attackerWeapon = attacker.getEquippedWeapon().getWeapon().getStats();
        WeaponStats attackeeWeapon = attackee.getEquippedWeapon().getWeapon().getStats();
        
        if (attackerWeapon == null)
            attackerWeapon = new WeaponStats();
        if (attackeeWeapon == null)
            attackeeWeapon = new WeaponStats();
        
        return new BattleStats(
            attacker,
            DamageCalculations.calculateHitPercentage(attackerStats, attackeeStats, attackerWeapon),
            DamageCalculations.calculateCriticalPercentage(attackerStats, attackerWeapon, attackeeStats),
            DamageCalculations.calculateAvoid(attackerStats),
            DamageCalculations.calculateSpeed(attackerStats, attackeeWeapon),
            DamageCalculations.calculateStrength(attackerStats, attackerWeapon),
            DamageCalculations.calculateHitTimes(attackerStats, attackerWeapon, attackeeStats, attackeeWeapon)
        );
    }

    public int getHitTimes()
    {
        return hitTimes;
    }
    
    public int getAvoid()
    {
        return avoid;
    }

    public int getCriticalPercentage()
    {
        return criticalPercentage;
    }

    public int getHitPercentage()
    {
        return hitPercentage;
    }

    public int getSpeed()
    {
        return speed;
    }

    public int getStrength()
    {
        return strength;
    }

    public Unit getUnit()
    {
        return unit;
    }
}

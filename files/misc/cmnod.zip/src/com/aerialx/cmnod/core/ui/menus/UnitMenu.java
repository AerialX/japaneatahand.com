package com.aerialx.cmnod.core.ui.menus;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.items.WeaponItem;
import com.aerialx.cmnod.core.states.BaseState;
import com.aerialx.cmnod.core.states.GameState;
import com.aerialx.cmnod.core.states.GameSubState;
import com.aerialx.cmnod.core.ui.AbstractMenu;
import com.aerialx.cmnod.core.ui.ColourActor;
import com.aerialx.cmnod.core.ui.Cursor;
import com.aerialx.cmnod.core.ui.MenuItem;
import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.util.Point;
import com.aerialx.util.Range;
import com.aerialx.util.Size;
import com.slickset.util.Bag;


/**
 * A menu that is displayed after moving a unit. For now only the attack item works.
 * @author Aaron Lindsay
 */
public class UnitMenu extends AbstractMenu
{
    public static final GameSubState GAME_SUBSTATE = new GameSubState("UnitMenu");
    protected Unit unit;

    public UnitMenu(Point position, BaseState state, Game game, Unit unit)
    {
        super(position, new Size(128, 24), state, game, UnitMenu.GAME_SUBSTATE);
        
        this.unit = unit;
        
        GameState gameState = (GameState)state;
        
        WeaponItem weapon = unit.getEquippedWeapon();
        if (weapon != null)
        {
            Bag<Point> attackPoints = gameState.getPointsInRange(weapon, gameState.getCursor().getDestinationX(), gameState.getCursor().getDestinationY(), weapon.getWeapon().getStats().getRange());
            
            for (Point point : attackPoints)
            {
                Unit newUnit = unit.getPlayer().getGame().getMap().getUnitAtPosition(point.getX(), point.getY());

                if (newUnit != null && newUnit.getPlayer() != unit.getPlayer())
                {
                    getItems().add(new Attack(this));
                    break;
                }
            }
        }
        
        getItems().add(new Items(this));
        
        
        Bag<Point> tradePoints = gameState.getPointsInRange(null, gameState.getCursor().getDestinationX(), gameState.getCursor().getDestinationY(), new Range(1, 1));
        for (Point point : tradePoints)
        {
            Unit newUnit = unit.getPlayer().getGame().getMap().getUnitAtPosition(point.getX(), point.getY());
            
            if (newUnit != null && newUnit.getPlayer() == unit.getPlayer())
            {
                //getItems().add(new Trade(this));
                break;
            }
        }
        
        getItems().add(new Wait(this));
    }

    public Unit getUnit()
    {
        return unit;
    }

    public class Attack extends MenuItem
    {

        public Attack(AbstractMenu menu)
        {
            super(menu, "Attack", "Attacks a unit within range.");
        }

        public void select()
        {
            UnitMenu unitMenu = (UnitMenu)menu;
            GameState gameState = unitMenu.getGame().getGameState();
            
            menu.hide();
            Cursor cursor = gameState.getCursor();
            cursor.setTask(Cursor.TASK_ATTACKUNIT);
            
            gameState.getHighlightedSpaces().removeAll();
            
            Bag<Point> attackPoints = gameState.getUnitAttackPoints(unitMenu.getUnit(), unitMenu.getUnit().getPosition());
            Bag<Point> points = new Bag<Point>();
            boolean firstSend = false;
            
            for (Point attackPoint : attackPoints)
            {
                Unit newUnit = game.getMap().getUnitAtPosition(attackPoint.getX(), attackPoint.getY());
                
                if (newUnit != null && newUnit.getPlayer() != unitMenu.getUnit().getPlayer())
                {
                    //Send the cursor to the first available attack point
                    if (!firstSend)
                    {
                        cursor.setDestinationX(attackPoint.getX());
                        cursor.setDestinationY(attackPoint.getY());
                        
                        firstSend = false;
                    }
                    
                    ColourActor square = new ColourActor(attackPoint.getScaledCopy(game.getMap().getTileSize()), new Size(game.getMap().getTileSize(), game.getMap().getTileSize()), gameState.getAttackColour(unit));
                    
                    gameState.getHighlightedSpaces().addActor(square);
                    
                    points.add(attackPoint);
                }
            }
            
            cursor.setTaskPoints(points);
        }
        
        public void hover()
        {
            UnitMenu unitMenu = (UnitMenu)menu;
            GameState gameState = unitMenu.getGame().getGameState();
            Bag<Point> attackPoints = gameState.getUnitAttackPoints(unitMenu.getUnit(), unitMenu.getUnit().getPosition());
            for (Point attackPoint : attackPoints)
            {
                Unit newUnit = game.getMap().getUnitAtPosition(attackPoint.getX(), attackPoint.getY());
                
                if (newUnit == null || newUnit.getPlayer() != unitMenu.getUnit().getPlayer())
                {
                    ColourActor square = new ColourActor(attackPoint.getScaledCopy(game.getMap().getTileSize()), new Size(game.getMap().getTileSize(), game.getMap().getTileSize()), gameState.getAttackColour(unit));
                    
                    gameState.getHighlightedSpaces().addActor(square);
                }
            }
        }
        
        public void unHover()
        {
            menu.getGame().getGameState().getHighlightedSpaces().removeAll();
        }
    }
    
    public class Staff extends MenuItem
    {
        public Staff(AbstractMenu menu)
        {
            super(menu, "Staff", "Uses an equipped staff.");
        }

        public void select()
        {
            
        }
    }
    
    public class Items extends MenuItem
    {
        public Items(AbstractMenu menu)
        {
            super(menu, "Items", "Use or organize items.");
        }

        public void select()
        {
            
        }
    }
    
    public class Trade extends MenuItem
    {
        public Trade(AbstractMenu menu)
        {
            super(menu, "Trade", "Trade items with a friendly adjacent unit.");
        }

        public void select()
        {
            
        }
    }
    
    public class Wait extends MenuItem
    {
        public Wait(AbstractMenu menu)
        {
            super(menu, "Wait", "Finish using the unit for this turn.");
        }

        public void select()
        {
            UnitMenu unitMenu = (UnitMenu)menu;
            unitMenu.hide();
            unitMenu.getUnit().setStatus(Unit.UNUSABLE);
            
            gameState.getGame().getGameState().checkForEndOfTurn();
        }
    }
}

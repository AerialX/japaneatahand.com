package com.aerialx.cmnod.core;

import com.aerialx.cmnod.core.items.Item;
import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.cmnod.core.util.tile.AnimatedTileLayer;
import com.aerialx.util.Point;
import com.aerialx.util.Size;
import org.newdawn.slick.util.pathfinding.Mover;
import org.newdawn.slick.util.pathfinding.TileBasedMap;

/**
 * Represents a game map.
 * @author Aaron Lindsay
 */
public class Map implements TileBasedMap
{

    protected Size size;
    protected Game game;
    protected int tileSize;
    protected AnimatedTileLayer.AnimatedTileModel tiles;

    public Map(Size size, int tileSize)
    {
        this.size = size;
        this.tileSize = tileSize;
    }
    
    public Unit getUnitAtPosition(int x, int y)
    {
        for (Player player : game.getPlayers())
        {
            for (Unit unit : player.getUnits())
            {
                if (unit.getPosition().getX() == x && unit.getPosition().getY() == y)
                    return unit;
                    
            }
        }
        
        return null;
    }

    public Unit getUnitAtPosition(Point point)
    {
        return getUnitAtPosition(point.getX(), point.getY());
    }
    
    
    public int getWidthInTiles()
    {
        return tiles.getWidth();
    }

    public int getHeightInTiles()
    {
        return tiles.getHeight();
    }

    public void pathFinderVisited(int x, int y)
    {
        
    }
    
    public Tile getTile(int x, int y)
    {
        return getTile(new Point(x, y));
    }
    
    public Tile getTile(Point point)
    {
        return (Tile)tiles.getTile(point.getX(), point.getY());
    }

    public boolean blocked(Mover mover, int x, int y)
    {
        if (mover instanceof Unit)
        {
            Unit unit = (Unit)mover;
            Unit newUnit = getUnitAtPosition(x, y);
            
            if (newUnit != null && newUnit.getPlayer() != unit.getPlayer())
                return true;
            else
                return getCost(unit.getCharacter().getUnitClass().getUnitType(), x, y) == -1;
        }
        else if (mover instanceof Item)
        {
            return false;
        }
        else
            return false;
    }

    public float getCost(Mover mover, int sx, int sy, int tx, int ty)
    {
        if (mover instanceof Unit)
        {
            Unit unit = (Unit)mover;

            return getCost(unit.getCharacter().getUnitClass().getUnitType(), tx, ty);
        }
        else if (mover instanceof Item)
        {
            //If it's a diagonal move, it costs 2
            if (sx == tx || sy == ty)
                return 1;
            else
                return 2;
        }
        else
            return 1;
    }
    
    public int getCost(UnitType unitType, int x, int y)
    {
        Tile tile = (Tile)tiles.getTile(x, y);
        
        return tile.getMovementCost(unitType);
    }
    
    public Game getGame()
    {
        return game;
    }

    public void setGame(Game val)
    {
        this.game = val;
    }

    public Size getSize()
    {
        return size;
    }

    public void setSize(Size val)
    {
        this.size = val;
    }

    public int getTileSize()
    {
        return tileSize;
    }

    public void setTileSize(int val)
    {
        this.tileSize = val;
    }

    public AnimatedTileLayer.AnimatedTileModel getTiles()
    {
        return tiles;
    }

    public void setTiles(AnimatedTileLayer.AnimatedTileModel val)
    {
        this.tiles = val;
    }
}


package com.aerialx.cmnod.core.items;

import java.util.ArrayList;

/**
 * An inventory is a group of items as an ArrayList. Used for the items a unit holds.
 * @author Aaron Lindsay
 */
public class Inventory<type extends Item> extends ArrayList<type>
{

    protected int limit;

    public Inventory(int limit)
    {
        this.limit = limit;
    }

    public int getLimit()
    {
        return limit;
    }

    @Override
    public boolean add(type e)
    {
        if (this.size() >= limit && limit >= 0)
        {
            return super.add(e);
        }
        else
        {
            return false;
        }
    }

    public boolean moveUp(int index)
    {
        if (index <= 0 && index > this.size())
        {
            return false;
        }

        type item = this.remove(index);
        this.add(index - 1, item);

        return true;
    }

    public boolean moveDown(int index)
    {
        if (index < 0 && index >= this.size())
        {
            return false;
        }

        type item = this.remove(index);
        this.add(index + 1, item);

        return true;
    }
}

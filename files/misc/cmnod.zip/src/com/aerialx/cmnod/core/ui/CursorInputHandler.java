package com.aerialx.cmnod.core.ui;

import com.aerialx.util.Point;
import com.slickset.layer.Viewport;
import org.newdawn.slick.Input;
import org.newdawn.slick.InputListener;
import org.newdawn.slick.geom.Rectangle;

/**
 * Input handler that controls the game's cursor
 * @author Aaron Lindsay
 */
public class CursorInputHandler implements InputListener {

    protected Cursor cursor;
    protected Input input;
    
    public CursorInputHandler(Cursor cursor)
    {
        this.cursor = cursor;
    }
    
    public void setInput(Input input)
    {
        this.input = input;
    }

    public boolean isAcceptingInput()
    {
        return cursor.isAcceptingInput();
    }

    public void inputEnded()
    {
        
    }

    public void keyPressed(int key, char c)
    {
        /*
        boolean changed = false;
        
        if (key == cursor.getKeyMoveLeft())
        {
            if (cursor.getDestinationX() > 0)
            {
                changed = true;
                cursor.setDestinationX(cursor.getDestinationX() - 1);
            }
        }
        else if (key == cursor.getKeyMoveRight())
        {
            if (cursor.getDestinationX() < cursor.getGame().getMap().getSize().getWidth() - 1)
            {
                changed = true;
                cursor.setDestinationX(cursor.getDestinationX() + 1);
            }
        }
        if (key == cursor.getKeyMoveUp())
        {
            if (cursor.getDestinationY() > 0)
            {
                changed = true;
                cursor.setDestinationY(cursor.getDestinationY() - 1);
            }
        }
        else if (key == cursor.getKeyMoveDown())
        {
            if (cursor.getDestinationY() < cursor.getGame().getMap().getSize().getHeight() - 1)
            {
                changed = true;
                cursor.setDestinationY(cursor.getDestinationY() + 1);
            }
        }
        
        if (changed)
            cursor.hover();
        
        if (key == cursor.getKeySelect())
        {
            cursor.select();
        }
        */
    }

    public void keyReleased(int key, char c)
    {
        
    }

    public void mouseWheelMoved(int change)
    {
        
    }

    public void mousePressed(int button, int x, int y)
    {
        if (button == 0)
        {
            if (!isOnMap(x, y))
                return;
            
            mouseMoved(x, y, x, y);
            
            cursor.select();
        }
    }

    public void mouseReleased(int button, int x, int y)
    {
        
    }

    public void mouseMoved(int oldx, int oldy, int newx, int newy)
    {
        if (!isOnMap(newx, newy))
            return;
        
        int destinationX = cursor.getDestinationX();
        int destinationY = cursor.getDestinationY();
        Viewport viewport = cursor.getGame().getGameState().getScene().getLayer().getViewport();
        Rectangle clip = viewport.getClip();
        int newX = (int)((newx + viewport.getX() - clip.getX()) / Cursor.CURSOR_IMAGE.getWidth());
        int newY = (int)((newy + viewport.getY() - clip.getY()) / Cursor.CURSOR_IMAGE.getHeight());
        boolean allowChange = false;
        
        switch (cursor.getTask())
        {
            case Cursor.TASK_NONE:
                allowChange = true;
                break;
            case Cursor.TASK_ATTACKUNIT:
                for (Point point : cursor.getTaskPoints())
                {
                    if (newX == point.getX() && newY == point.getY())
                    {
                        allowChange = true;
                        break;
                    }
                }
                break;
        }
        
        if (allowChange)
        {
            cursor.setDestinationX(newX);
            cursor.setDestinationY(newY);
        }
        
        if (allowChange && (destinationX != newX || destinationY != newY))
            cursor.hover(destinationX, destinationY);
    }
    
    private boolean isOnMap(int x, int y)
    {
        Rectangle clip = cursor.getGameState().getScene().getLayer().getViewport().getClip();   
        
        if (x >= clip.getX() && y >= clip.getY() && x <= clip.getX() + clip.getWidth() && y <= clip.getY() + clip.getHeight())
            return true;
        else
            return false;
    }

    public void controllerLeftPressed(int controller)
    {
        
    }

    public void controllerLeftReleased(int controller)
    {
        
    }

    public void controllerRightPressed(int controller)
    {
        
    }

    public void controllerRightReleased(int controller)
    {
        
    }

    public void controllerUpPressed(int controller)
    {
        
    }

    public void controllerUpReleased(int controller)
    {
        
    }

    public void controllerDownPressed(int controller)
    {
        
    }

    public void controllerDownReleased(int controller)
    {
        
    }

    public void controllerButtonPressed(int controller, int button)
    {
        
    }

    public void controllerButtonReleased(int controller, int button)
    {
        
    }

}

package com.aerialx.cmnod.core.ui;

import com.aerialx.cmnod.core.states.BaseState;
import com.slickset.Actor;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.state.StateBasedGame;

/**
 * Shows a short message on the screen like notifications about a player's turn
 * @author Aaron Lindsay
 */
public class ShortInformation extends Actor
{

    protected BaseState state;
    protected String message;
    protected int lifetime;
    protected int time;
    protected Color fadeColour;
    public static int DEFAULT_LIFETIME = 2000;
    public static int FADE_TIME = 500;

    public ShortInformation(BaseState state, String message)
    {
        this(state, message, DEFAULT_LIFETIME);
    }

    public ShortInformation(BaseState state, String message, int lifetime)
    {
        super(
            state.getScene().getLayer().getViewport().getClip().getWidth() / 2,
            state.getScene().getLayer().getViewport().getClip().getHeight() / 2
        );

        this.message = message;
        this.lifetime = lifetime;
        this.state = state;

        this.time = 0;
        this.fadeColour = new Color(0F, 0F, 0F, 0F);

        this.state.getMenus().addActor(this);
    }

    public void update(StateBasedGame game, int delta)
    {
        super.update(game, delta);

        time += delta;

        if (time <= FADE_TIME)
        {
            fadeColour.a = 1F - (float)(FADE_TIME - time) / (float)FADE_TIME;
        }
        else if (time > FADE_TIME + lifetime)
        {
            fadeColour.a = (float)(FADE_TIME + lifetime + FADE_TIME - time) / (float)FADE_TIME;
        }

        if (time > FADE_TIME * 2 + lifetime)
        {
            state.getMenus().removeActor(this);
        }
    }

    @Override
    public void render(Graphics g, float x, float y)
    {
        g.setColor(fadeColour);
        g.drawString(message, x, y);
    }
}

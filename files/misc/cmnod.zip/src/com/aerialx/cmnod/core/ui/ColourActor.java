package com.aerialx.cmnod.core.ui;

import com.aerialx.util.Point;
import com.aerialx.util.Size;
import com.slickset.Actor;
import com.slickset.collision.Box;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.geom.Rectangle;

/**
 * A colour actor is just a solid block of colour on the scene. Used for range
 * notifications.
 * @author Aaron Lindsay
 */
public class ColourActor extends Actor {
    protected Color colour;
    
    public ColourActor(Point position, Size size, Color colour)
    {
        super(null, position.getX(), position.getY(), new Box(size.getWidth(), size.getHeight()));
        
        this.colour = colour;
    }

    public void render(Graphics g, float x, float y)
    {
        g.setColor(colour);
        g.fill(new Rectangle(x, y, getWidth(), getHeight()));
    }

    public Color getColour()
    {
        return colour;
    }

    public void setColour(Color colour)
    {
        this.colour = colour;
    }
}

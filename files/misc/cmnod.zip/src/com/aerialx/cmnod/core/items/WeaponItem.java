package com.aerialx.cmnod.core.items;

import com.aerialx.cmnod.core.units.Unit;

/**
 * Represents an instance of a weapon.
 * @author Aaron Lindsay
 */
public class WeaponItem extends EquippableItem
{
    protected Weapon weapon;
    protected int uses;

    public WeaponItem(Weapon weapon)
    {
        super(weapon.getName(), weapon.getDescription());
        
        this.weapon = weapon;
        this.uses = 0;
    }
    
    public boolean canEquip(Unit unit)
    {
        // Weapons without type may be weilded by *any* unit regardless of skill
        if (weapon.getType() == null)
            return true;
        
        if (unit.getSkills().containsKey(weapon.getType()) && unit.getSkills().get(weapon.getType()) >= weapon.getMinSkill())
            return true;
        
        return false;
    }

    public boolean equip(Unit unit)
    {
        if (unit.getEquippedWeapon() == null)
            return super.equip(unit);
        
        return false;
    }

    public int getUses()
    {
        return uses;
    }

    public void setUses(int val)
    {
        this.uses = val;
    }

    public Weapon getWeapon()
    {
        return weapon;
    }

    public void setWeapon(Weapon val)
    {
        this.weapon = val;
    }
}


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.aerialx.cmnod.core.util.xml;

import com.aerialx.cmnod.core.units.UnitClass;
import com.aerialx.cmnod.core.util.NlrudAnimationSelector;
import com.aerialx.cmnod.core.units.Character;
import com.aerialx.util.Misc;
import com.aerialx.util.Size;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Hashtable;
import javax.xml.xpath.*;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * Loads and maintains characters from an XML definition
 * @author Aaron Lindsay
 */
public class XmlCharacters {
    public static Hashtable<String, Character> loaded;
    
    public static void loadCharacters()
    {
        loaded = new Hashtable<String, Character>();
        
        File directory = new File("res/Definitions/Characters");
        
        File[] files = directory.listFiles();
        
        for (File file : files) {
            InputSource inputSource = null;
            XPath xPath;
            NodeList nodes = null;

            XPathFactory factory = XPathFactory.newInstance();

            xPath = factory.newXPath();
            
            try {
                inputSource = new InputSource(new FileInputStream(file.getPath()));
            } catch (FileNotFoundException ex) { }
            
            try {
            nodes = (NodeList)xPath.evaluate("/character", inputSource, XPathConstants.NODESET);
            } catch (XPathExpressionException ex) { }
            
            for (int i = 0; i < nodes.getLength(); i++)
            {
                Node node = nodes.item(i);
                NodeList list = node.getChildNodes();
                String cName = null;
                UnitClass cClass = null;
                Animation[] cMapAnimations = null;
                Animation[] cBattleAnimations = null;
                float[] cBattleXdelta = null;
                int cAttackFrame = 0;
                Size cSize = null;
                
                for (int j = 0; j < list.getLength(); j++) {
                    node = list.item(j);

                    if (node.getNodeName().equalsIgnoreCase("name"))
                    {
                        cName = node.getTextContent().trim();
                    }
                    else if (node.getNodeName().equalsIgnoreCase("class"))
                    {
                        cClass = XmlClasses.loaded.get(node.getTextContent().trim());
                    }
                    else if (node.getNodeName().equalsIgnoreCase("mapanimations"))
                    {
                        Node nlrud = node.getFirstChild();
                        NamedNodeMap nlrudAttributes = nlrud.getAttributes();
                        NamedNodeMap spriteSheet = nlrud.getFirstChild().getAttributes();
                        
                        try {
                            cMapAnimations = NlrudAnimationSelector.splitUpSpriteSheet(
                                new SpriteSheet(
                                    new Image(spriteSheet.getNamedItem("image").getNodeValue()),
                                    Integer.parseInt(spriteSheet.getNamedItem("tilewidth").getNodeValue()),
                                    Integer.parseInt(spriteSheet.getNamedItem("tileheight").getNodeValue())
                                ),
                                new Image(nlrud.getLastChild().getAttributes().getNamedItem("image").getNodeValue()),
                                Integer.parseInt(nlrudAttributes.getNamedItem("neutral").getNodeValue()),
                                Integer.parseInt(nlrudAttributes.getNamedItem("left").getNodeValue()),
                                Integer.parseInt(nlrudAttributes.getNamedItem("right").getNodeValue()),
                                Integer.parseInt(nlrudAttributes.getNamedItem("up").getNodeValue()),
                                Integer.parseInt(nlrudAttributes.getNamedItem("down").getNodeValue())
                            );
                        } catch (SlickException ex) { }
                    }
                    else if (node.getNodeName().equalsIgnoreCase("battleanimations"))
                    {
                        try {
                            NamedNodeMap attributes = node.getFirstChild().getAttributes();
                            cBattleAnimations = Misc.createBattleAnimationsFromFolder(attributes.getNamedItem("folder").getNodeValue(), Integer.parseInt(attributes.getNamedItem("frameduration").getNodeValue()));
                        } catch (SlickException ex) { }
                    }
                    else if (node.getNodeName().equalsIgnoreCase("battlexdelta"))
                    {
                        NodeList deltas = node.getChildNodes();
                        ArrayList<Float> xDeltas = new ArrayList<Float>();
                        
                        for (int k = 0; k < deltas.getLength(); k++) {
                            Node deltaNode = deltas.item(k);
                            
                            if (deltaNode.getNodeName().equalsIgnoreCase("delta"))
                                xDeltas.add(Float.parseFloat(deltaNode.getAttributes().getNamedItem("value").getNodeValue()));
                        }
                        cBattleXdelta = Misc.toArrayFromFloatList(xDeltas);
                    }
                    else if (node.getNodeName().equalsIgnoreCase("attackframe"))
                    {
                        cAttackFrame = Integer.parseInt(node.getTextContent().trim());
                    }
                    else if (node.getNodeName().equalsIgnoreCase("size"))
                    {
                        NamedNodeMap attributes = node.getAttributes();
                        
                        cSize = new Size(
                            Integer.parseInt(attributes.getNamedItem("width").getNodeValue()),
                            Integer.parseInt(attributes.getNamedItem("height").getNodeValue())
                        );
                    }
                }

                Character character = new Character(cClass, cName, cMapAnimations, cBattleAnimations, cBattleXdelta, cAttackFrame, cSize);
                
                loaded.put(cName, character);
            }
        }
    }
}

package com.aerialx.cmnod.core.units;

import com.aerialx.util.Point;
import com.slickset.Actor;
import com.slickset.AnimatedActor;
import com.slickset.collision.Box;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.Image;

/**
 * An instance of a unit in battle
 * @author Aaron Lindsay
 */
public class BattleUnit extends AnimatedActor
{

    protected Actor target;
    protected Unit unit;
    protected int direction;
    protected boolean attackOnce;
    protected int attacks;
    protected int deathAnimation;
    protected Color deathColour;
    protected boolean attacked;
    public static final int STATUS_WAITING = 0;
    public static final int STATUS_ATTACKING = 1;
    public static final int ATTACK_DISTANCE = 100;
    public static final int DEATH_FADEOUT = 500;

    public BattleUnit(Unit unit)
    {
        super(unit.getCharacter().getBattleAnimations(),
            0,
            0,
            new Box(unit.getCharacter().getSize().getWidth(), unit.getCharacter().getSize().getHeight()),
            1.0F,
            false);

        this.unit = unit;
        
        this.attacks = 0;
        this.attackOnce = true;
        this.deathAnimation = 0;
        this.deathColour = new Color(1F, 1F, 1F, 1F);
        
        setStatus(STATUS_WAITING);
    }

    @Override
    public void update(StateBasedGame game, int delta)
    {
        if (getStatus() == STATUS_ATTACKING)
        {
            setX(target.getX() + (target.getWidth() / 2 + ATTACK_DISTANCE * unit.getCharacter().getBattleXdelta()[getCurrentAnimation().getFrame()]) * direction);
            
            if (getCurrentAnimation().getFrame() == unit.getCharacter().getAttackFrame() && !attacked)
            {
                unit.getPlayer().getGame().getBattleState().attack();
                attacked = true;
            }
            else if (getCurrentAnimation().getFrame() == getCurrentAnimation().getFrameCount() - 1)
                attacked = false;
            
            if (attackOnce && getCurrentAnimation().getFrame() == getCurrentAnimation().getFrameCount() - 1)
            {
                attacks++;
                getCurrentAnimation().setCurrentFrame(0);
                setStatus(STATUS_WAITING);
            }
        }
        
        if (unit.isDead())
        {
            deathAnimation += delta;
            
            if (deathAnimation <= DEATH_FADEOUT)
            {
                deathColour.a = (float)(DEATH_FADEOUT - deathAnimation) / (float)DEATH_FADEOUT;
            }
        }
        
        super.update(game, delta);
    }

    @Override
    public void render(Graphics g, float x, float y)
    {
        Image image = getCurrentAnimation().getCurrentFrame();
        
        if (direction == -1)
            image = image.getFlippedCopy(true, false);
        
        Point offset = unit.getCharacter().getOffset();
        g.drawImage(image, x + offset.getX(), y + offset.getY(), deathColour);
    }

    public int getDeathAnimation()
    {
        return deathAnimation;
    }
    
    public int getAttacks()
    {
        return attacks;
    }
    
    public void setAttackOnce(boolean attackOnce)
    {
        this.attackOnce = attackOnce;
    }

    public boolean getAttackOnce()
    {
        return attackOnce;
    }
    
    public void setTarget(Actor target)
    {
        this.target = target;
        
        direction = (int)Math.signum(getX() - target.getX());
    }
    
    @Override
    protected void selectAnimation(int oldStatus, int oldDirection, int newStatus, int newDirection)
    {
        setAnimation(newStatus);
        
        if (newStatus == STATUS_WAITING && target != null)
            setX(target.getX() + (target.getWidth() / 2 + ATTACK_DISTANCE) * direction);
    }
}

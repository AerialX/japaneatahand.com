package com.aerialx.cmnod.core.items;

import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.cmnod.core.units.UnitStats;

/**
 * Helper class that makes an item that can be equipped and modifies a unit's stats.
 * @author Aaron Lindsay
 */
public class StatModifierItem extends EquippableItem
{

    protected UnitStats stats;
    
    public StatModifierItem(String name, String description, UnitStats stats)
    {
        super(name, description);
        
        this.stats = stats;
    }

    @Override
    public boolean canEquip(Unit unit)
    {
        return true;
    }

    @Override
    public boolean equip(Unit unit)
    {
        if (super.equip(unit))
        {
            if (!unit.getBoosts().add(stats))
            {
                unit.getEquippedItems().remove(this);
                
                return false;
            }
            
            return true;
        }
        
        return false;
    }

    @Override
    public boolean unequip(Unit unit)
    {
        if (super.unequip(unit))
        {
            unit.getBoosts().remove(stats);
            
            return true;
        }
        
        return false;
    }
}


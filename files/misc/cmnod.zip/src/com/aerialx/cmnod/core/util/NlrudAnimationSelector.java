package com.aerialx.cmnod.core.util;

import com.aerialx.cmnod.core.units.Unit;
import com.slickset.AnimatedActor;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;
import org.newdawn.slick.Image;
import org.newdawn.slick.ImageBuffer;
import org.newdawn.slick.SpriteSheet;

/**
 * Defines a way to show map animation, with a column for each NLRUD (Neutral,
 * Left, Right, Up, Down)
 * @author Aaron Lindsay
 */
public class NlrudAnimationSelector {
    public static final int FRAME_DURATION = 300;
    public static final int NEUTRAL = 0;
    public static final int DISABLED = 1;
    public static final int LEFT = 2;
    public static final int RIGHT = 3;
    public static final int UP = 4;
    public static final int DOWN = 5;
    
    public static int getAnimation(int direction, int status)
    {
        switch (direction)
        {
            case AnimatedActor.NONE:
                if (status == Unit.USABLE)
                    return NEUTRAL;
                else
                    return DISABLED;
            case AnimatedActor.LEFT:
                return LEFT;
            case AnimatedActor.RIGHT:
                return RIGHT;
            case AnimatedActor.UP:
                return UP;
            case AnimatedActor.DOWN:
                return DOWN;
            default:
                return 0;
        }
    }
    
    public static Animation[] splitUpSpriteSheet(SpriteSheet sheet, Image disabled, int neutral, int left, int right, int up, int down)
    {
        return splitUpSpriteSheet(sheet, disabled, FRAME_DURATION, neutral, left, right, up, down);
    }
    
    public static Animation[] splitUpSpriteSheet(SpriteSheet sheet, Image disabled, int frameDuration, int neutral, int left, int right, int up, int down)
    {
        Animation animation;
        Animation[] animations = new Animation[6];
        
        //Neutral
        animation = new Animation(true);
        for (int x = 0; x < neutral; x++)
        {
            animation.addFrame(sheet.getSprite(x, 0), frameDuration);
        }
        animations[0] = animation;
        
        //Disabled Neutral
        animation = new Animation(true);
        //animation.addFrame(desaturateImage(sheet.getSprite(0, 0)), frameDuration);
        animation.addFrame(disabled, frameDuration);
        animations[1] = animation;
        
        //Left
        animation = new Animation(true);
        for (int x = 0; x < left; x++)
        {
            animation.addFrame(sheet.getSprite(x, 1), frameDuration);
        }
        animations[2] = animation;
        
        //Right
        animation = new Animation(true);
        for (int x = 0; x < right; x++)
        {
            animation.addFrame(sheet.getSprite(x, 2), frameDuration);
        }
        animations[3] = animation;
        
        
        //Up
        animation = new Animation(true);
        for (int x = 0; x < up; x++)
        {
            animation.addFrame(sheet.getSprite(x, 3), frameDuration);
        }
        animations[4] = animation;

        //Down
        animation = new Animation(true);
        for (int x = 0; x < down; x++)
        {
            animation.addFrame(sheet.getSprite(x, 4), frameDuration);
        }
        animations[5] = animation;
        
        return animations;
    }
    
    private static Image desaturateImage(Image image)
    {
        ImageBuffer data = new ImageBuffer(image.getWidth(), image.getHeight());
        
        for (int x = 0; x < image.getWidth(); x++)
        {
            for (int y = 0; y < image.getHeight(); y++)
            {
                //Get the average of each rgb byte in the colour (but retain alpha)
                Color colour = image.getColor(x, y);
                int rgb = (colour.getRedByte() + colour.getGreenByte() + colour.getBlueByte()) / 3;
                
                data.setRGBA(x, y, rgb, rgb, rgb, colour.getAlphaByte());
            }
        }
        
        return data.getImage();
    }
}

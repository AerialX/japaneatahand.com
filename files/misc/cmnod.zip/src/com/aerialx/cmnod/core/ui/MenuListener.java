package com.aerialx.cmnod.core.ui;

import java.util.ArrayList;
import org.newdawn.slick.Input;
import org.newdawn.slick.InputListener;

/**
 * Listens to input events and uses them to act upon the listener's menu
 * @author Aaron Lindsay
 */
public class MenuListener implements InputListener
{
    protected Input input;
    protected AbstractMenu menu;
    //HACK:
    protected boolean movedOnce = false;
    
    public MenuListener(AbstractMenu menu)
    {
        this.menu = menu;
    }
    
    public void setInput(Input input)
    {
        this.input = input;
    }

    public boolean isAcceptingInput()
    {
        return menu.isAcceptingInput();
    }

    public void inputEnded()
    {
        
    }

    public void keyPressed(int key, char c)
    {
        switch (key)
        {
            case AbstractMenu.KEY_UP:
                menu.selectUp();
                break;
            case AbstractMenu.KEY_DOWN:
                menu.selectDown();
                break;
                /*
            case AbstractMenu.KEY_LEFT:
                menu.selectLeft();
                break;
            case AbstractMenu.KEY_RIGHT:
                menu.selectRight();
                break;
                */
            case AbstractMenu.KEY_SELECT:
                menu.selectItem();
                break;
        }
    }

    public void keyReleased(int key, char c)
    {
        
    }

    public void mouseWheelMoved(int change)
    {
        
    }

    public void mousePressed(int button, int x, int y)
    {
        if (movedOnce && button == 0)
        {
            int width = menu.getItemSize().getWidth();
            int height = menu.getItemSize().getHeight();
            
            if (x >= menu.getScreenX() && x <= menu.getScreenX() + menu.getColumns() * width && y >= menu.getScreenY() && y <= menu.getScreenY() + menu.getRows() * height)
                menu.selectItem();
        }
    }

    public void mouseReleased(int button, int x, int y)
    {
        
    }

    public void mouseMoved(int oldx, int oldy, int newx, int newy)
    {
        movedOnce = true;
        
        int width = menu.getItemSize().getWidth();
        int height = menu.getItemSize().getHeight();
        float x = menu.getScreenX() + menu.getColumns() * width;
        float y = menu.getScreenY() + menu.getRows() * height;
        
        if (newx >= menu.getScreenX() && newx <= x && newy >= menu.getScreenY() && newy <= y)
        {
            ArrayList<MenuItem> items = menu.getItems();menu.getItems();
            for (int i = 0; i < items.size(); i++)
            {
                float itemx = menu.getScreenX() + (i % menu.getColumns()) * width;
                float itemy = menu.getScreenY() + (i % menu.getRows()) * height;
                
                if (newx >= itemx && newx <= itemx + width && newy >= itemy && newy <= itemy + height)
                {
                    menu.setSelectedItem(i);
                }
            }
        }
    }

    public void controllerLeftPressed(int controller)
    {
        
    }

    public void controllerLeftReleased(int controller)
    {
        
    }

    public void controllerRightPressed(int controller)
    {
        
    }

    public void controllerRightReleased(int controller)
    {
        
    }

    public void controllerUpPressed(int controller)
    {
        
    }

    public void controllerUpReleased(int controller)
    {
        
    }

    public void controllerDownPressed(int controller)
    {
        
    }

    public void controllerDownReleased(int controller)
    {
        
    }

    public void controllerButtonPressed(int controller, int button)
    {
        
    }

    public void controllerButtonReleased(int controller, int button)
    {
        
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aerialx.cmnod.core.ui;

import com.aerialx.cmnod.core.states.GameState;
import com.aerialx.cmnod.core.units.Unit;
import com.slickset.Actor;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.Color;

/**
 * Shows a little box in the top-right corner about the currently hovered unit
 * @author Aaron Lindsay
 */
public class UnitQuickInfo extends Actor
{

    protected GameState state;
    protected boolean show;
    public Unit unit;

    public UnitQuickInfo(GameState state)
    {
        super(state.getStateBasedGame().getContainer().getWidth() - 10 - 100, 10);

        this.state = state;
        
        this.show = false;
        
    }

    public void update(StateBasedGame game, int delta)
    {
        super.update(game, delta);
        
        unit = state.getGame().getMap().getUnitAtPosition(state.getCursor().getDestination());
    }

    public void render(Graphics g, float x, float y)
    {
        if (unit != null)
        {
            Color playerColour = new Color(unit.getPlayer().getColour());
            playerColour.a = 0.6F;
            g.setColor(playerColour);
            
            g.fillRect(x, y, 100, 80);
            
            g.setColor(Color.white);
            
            g.drawString(unit.getPlayer().getName(), x + 5, y);
            g.drawString(unit.getCharacter().getName(), x + 5, y + 20);
            if (unit.getEquippedWeapon() != null)
            {
                //TODO: Draw weapon icon to the left of its name
                g.drawString(unit.getEquippedWeapon().getName(), x + 25, y + 40);
            }
            g.drawString("HP: " + ((Integer)unit.getHealth()).toString() + " / " + ((Integer)unit.getCombinedStats().getHealth()).toString(), x + 5, y + 60);
        }
    }
}

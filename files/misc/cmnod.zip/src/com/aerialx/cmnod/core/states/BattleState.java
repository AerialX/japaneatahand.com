package com.aerialx.cmnod.core.states;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.ui.BattleHP;
import com.aerialx.cmnod.core.ui.ShortInformation;
import com.aerialx.cmnod.core.units.BattleUnit;
import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.cmnod.core.util.BattleStats;
import com.slickset.ActorGroup;
import com.slickset.Scene;
import com.slickset.layer.ImageLayer;
import java.util.Random;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

/**
 * BattleState is when two units meet in battle.
 * @author Aaron Lindsay
 */
public class BattleState extends BaseState
{
    // A group that holds each unit on the battle screen
    protected ActorGroup attackers;
    // A group that just holds the bars that show each unit's HP
    protected ActorGroup hpBars;
    // The unit that's attacking
    protected Unit attackerUnit;
    // THe unit that's being attacked
    protected Unit attackeeUnit;
    // Information about the unit attacking
    protected BattleUnit battleAttacker;
    protected BattleStats attacker;
    // Information about the unit being attacked
    protected BattleUnit battleAttackee;
    protected BattleStats attackee;
    // Holds the time the battle has taken
    protected int time;
    // Used for randomizing results like misses and critical hits
    protected Random random;
    
    public static final int ID = 2;
    public static final int DELAY_START = 0;

    public BattleState(Game game)
    {
        super(game);

        game.setBattleState(this);
        
        this.attackers = new ActorGroup("Attackers");
        this.hpBars = new ActorGroup("HP Bars");
        this.time = -1;
        this.random = new Random();
    }

    @Override
    public int getID()
    {
        return BattleState.ID;
    }

    public Game getGame()
    {
        return game;
    }

    public void beginBattle(Unit attacker, Unit attackee)
    {
        this.attackerUnit = attacker;
        this.attackeeUnit = attackee;
        this.battleAttacker = new BattleUnit(attacker);
        this.battleAttackee = new BattleUnit(attackee);
        time = 0;
        attackers.addActor(battleAttacker);
        attackers.addActor(battleAttackee);
        
        battleAttackee.setX(200);
        battleAttackee.setY(350);
        battleAttackee.setStatus(BattleUnit.STATUS_WAITING);
        battleAttacker.setX(battleAttackee.getX() + battleAttackee.getWidth() / 2 + BattleUnit.ATTACK_DISTANCE);
        battleAttacker.setY(battleAttackee.getY());
        battleAttacker.setStatus(BattleUnit.STATUS_WAITING);
        
        battleAttacker.setTarget(battleAttackee);
        battleAttackee.setTarget(battleAttacker);
        
        this.attacker = BattleStats.generateStats(attacker, attackee);
        this.attackee = BattleStats.generateStats(attackee, attacker);
        
        BattleHP attackerBar = new BattleHP(attacker, (int)battleAttacker.getX() + attackerUnit.getCharacter().getOffset().getX(), (int)battleAttacker.getY() + (int)battleAttacker.getHeight() + attackerUnit.getCharacter().getOffset().getY() + 10);
        BattleHP attackeeBar = new BattleHP(attackee, (int)battleAttackee.getX() + attackeeUnit.getCharacter().getOffset().getX(), (int)battleAttackee.getY() + (int)battleAttackee.getHeight() + attackeeUnit.getCharacter().getOffset().getY() + 10);
        hpBars.addActor(attackerBar);
        hpBars.addActor(attackeeBar);
    }
    
    public void endBattle()
    {
        attackers.removeAll();
        hpBars.removeAll();
        
        game.toMapView();
    }

    public void postInit(GameContainer container, StateBasedGame sbg) throws SlickException
    {
        //TODO: Temporary image
        Image image = new Image("res/Backgrounds/Trees.png").getScaledCopy(640, 480);
        ImageLayer layer = new ImageLayer(image);
        scene.setLayer(layer);
        
        scene.addGroup(attackers);
        scene.addGroup(hpBars);
    }

    public void render(GameContainer container, StateBasedGame game, Graphics g) throws SlickException
    {
        scene.render(g);
        scene.renderActors(g);
    }

    public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException
    {
        scene.update(game, delta);
        
        if (time == -1)
            return;
        
        if (!checkAttacking())
            if (!nextAttack())
                endBattle();
    }

    private boolean checkAttacking()
    {
        return (battleAttacker.getStatus() == BattleUnit.STATUS_ATTACKING || battleAttackee.getStatus() == BattleUnit.STATUS_ATTACKING);
    }
    
    private boolean nextAttack()
    {
        if (attackerUnit.isDead())
        {
             if (battleAttacker.getDeathAnimation() < BattleUnit.DEATH_FADEOUT)
                 return true;
             else
                 return false;
        }
        else if (attackeeUnit.isDead())
        {
            if (battleAttackee.getDeathAnimation() < BattleUnit.DEATH_FADEOUT)
                return true;
            else
                return false;
        }
        
        if (battleAttacker.getAttacks() == attacker.getHitTimes() && battleAttackee.getAttacks() == attackee.getHitTimes())
        {
            return false;
        }
        
        if (battleAttacker.getAttacks() == battleAttackee.getAttacks())
        {
            if (attacker.getSpeed() == attackee.getSpeed())
            {
                if (battleAttacker.getAttacks() < attacker.getHitTimes())
                    battleAttacker.setStatus(BattleUnit.STATUS_ATTACKING);
                else
                    battleAttackee.setStatus(BattleUnit.STATUS_ATTACKING);
            }
            else if (attacker.getSpeed() > attackee.getSpeed() && battleAttacker.getAttacks() < attacker.getHitTimes())
            {
                battleAttacker.setStatus(BattleUnit.STATUS_ATTACKING);
            }
            else
            {
                battleAttackee.setStatus(BattleUnit.STATUS_ATTACKING);
            }
        }
        else if (battleAttacker.getAttacks() < battleAttackee.getAttacks() && battleAttacker.getAttacks() < attacker.getHitTimes())
        {
            battleAttacker.setStatus(BattleUnit.STATUS_ATTACKING);
        }
        else
        {
            battleAttackee.setStatus(BattleUnit.STATUS_ATTACKING);
        }
        
        return true;
    }
    
    public void attack()
    {
        Unit attackerUnit;
        BattleUnit attackerBattle;
        BattleStats attackerStats;
        Unit attackeeUnit;
        BattleUnit attackeeBattle;
        BattleStats attackeeStats;
        
        if (battleAttacker.getStatus() == BattleUnit.STATUS_ATTACKING)
        {
            attackerUnit = this.attackerUnit;
            attackerBattle = battleAttacker;
            attackerStats = attacker;
            attackeeUnit = this.attackeeUnit;
            attackeeBattle = battleAttackee;
            attackeeStats = attackee;
        }
        else if (battleAttackee.getStatus() == BattleUnit.STATUS_ATTACKING)
        {
            attackerUnit = this.attackeeUnit;
            attackerBattle = battleAttackee;
            attackerStats = attackee;
            attackeeUnit = this.attackerUnit;
            attackeeBattle = battleAttacker;
            attackeeStats = attacker;
        }
        else
            return;
        
        if (random.nextInt(101) > attackerStats.getHitPercentage())
        {
            //Miss
            //TODO: Make a "Miss!" Actor that hovers over for a second or two.
            new ShortInformation(this, "Miss!", 1001);
            return;
        }
        
        int damage;
        int newHealth;
        
        damage = attackerStats.getStrength() - attackerUnit.getCombinedStats().getDefence();
        
        if (random.nextInt(101) <= attackerStats.getCriticalPercentage())
        {
            //Critical hit
            damage += attackerStats.getStrength() * 2;
        }
        
        newHealth = attackeeUnit.getHealth() - damage;
        
        if (newHealth <= 0)
            newHealth = 0;
        
        attackeeUnit.setHealth(newHealth);
    }
    
    public Scene getScene()
    {
        return scene;
    }
}

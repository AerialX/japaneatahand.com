package com.aerialx.cmnod.core.states;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.Player;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;

/**
 * A state that shows information about a specified player. Unused.
 * @author Aaron Lindsay
 */
public class PlayerStatsState extends BaseState {

    public static final int ID = 4;
    protected Player player;
    
    public PlayerStatsState(Game game)
    {
        this(game, null);
    }
    
    public PlayerStatsState(Game game, Player player)
    {
        super(game);
        
        if (player != null)
        {
            setPlayer(player);
        }
    }

    public void setPlayer(Player player)
    {
        this.player = player;
        
        //TODO: Set up labels and stuff...
    }

    public Player getPlayer()
    {
        return player;
    }
    
    public int getID()
    {
        return PlayerStatsState.ID;
    }

    public void render(GameContainer container, StateBasedGame game, Graphics g) throws SlickException
    {
        
    }

    public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException
    {
        
    }
}

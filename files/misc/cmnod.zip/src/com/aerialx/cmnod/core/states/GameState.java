package com.aerialx.cmnod.core.states;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.Player;
import com.aerialx.cmnod.core.items.Item;
import com.aerialx.cmnod.core.items.WeaponItem;
import com.aerialx.cmnod.core.ui.ColourActor;
import com.aerialx.cmnod.core.ui.Cursor;
import com.aerialx.cmnod.core.ui.ShortInformation;
import com.aerialx.cmnod.core.ui.UnitQuickInfo;
import com.aerialx.cmnod.core.ui.menus.MapMenu;
import com.aerialx.cmnod.core.ui.menus.UnitMenu;
import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.cmnod.core.util.pathfinding.AStarCostablePathFinder;
import com.aerialx.cmnod.core.util.tile.AnimatedTileLayer;
import com.aerialx.util.Point;
import com.aerialx.util.Range;
import com.aerialx.util.Size;
import com.slickset.ActorGroup;
import com.slickset.util.Bag;
import java.util.Hashtable;
import java.util.Set;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.util.pathfinding.Mover;
import org.newdawn.slick.util.pathfinding.Path;

/**
 * The GameState is the main view of the game and map where players control units.
 * @author Aaron Lindsay
 */
public class GameState extends BaseState
{
    // A group that represents each unit on-screen
    protected ActorGroup units;
    // A group that represents highlit spaces like showing a unit's path
    protected ActorGroup highlightedSpaces;
    // A group that just holds the cursor on the map
    protected ActorGroup cursorGroup;
    // A group that holds any menus or other UI items
    protected ActorGroup uiInfo;
    // The Cursor class that controls the cursor seen on-screen
    protected Cursor cursor;
    
    public static final int ID = 1;
    public static final Color ENEMY_MOVEMENT_COLOUR = new Color(255, 220, 0, 128);
    public static final Color ENEMY_ATTACK_COLOUR = new Color(255, 0, 0, 128);
    public static final Color OWN_MOVEMENT_COLOUR = new Color(0, 40, 255, 128);
    public static final Color OWN_ATTACK_COLOUR = new Color(255, 255, 40, 192);

    //Runs to start a new game
    public GameState(Game game)
    {
        super(game);
        
        //Set the game's game state to this new one
        game.setGameState(this);
        
        //Set up al the groups (see above for specific info)
        highlightedSpaces = new ActorGroup("Highlighted Spaces");
        units = new ActorGroup("Units");
        cursorGroup = new ActorGroup("Cursor");
        uiInfo = new ActorGroup("UI Info");
    }

    public int getID()
    {
        return ID;
    }

    //Happens when the state is initialized
    public void postInit(GameContainer container, StateBasedGame sbg) throws SlickException
    {
        //Create the map, starting with a tile layer
        AnimatedTileLayer tileLayer = new AnimatedTileLayer(game.getMap().getSize().getWidth(), game.getMap().getSize().getHeight(), game.getMap().getTileSize());
        scene.setLayer(tileLayer);
        
        game.getMap().setTiles((AnimatedTileLayer.AnimatedTileModel)tileLayer.getData());

        scene.addGroup(highlightedSpaces);

        //Add each player's units to the map
        for (Player player : game.getPlayers())
        {
            for (Unit unit : player.getUnits())
            {
                units.addActor(unit);
            }
        }
        scene.addGroup(units);

        //Create the cursor
        cursor = new Cursor(game);
        cursorGroup.addActor(cursor);
        scene.addGroup(cursorGroup);
        cursor.takeFocus();
        
        //Tell it to hover over the top-left point
        cursorHoverSpace(new Point(0, 0));
        
        // Set up the quick-info box
        UnitQuickInfo unitInfo = new UnitQuickInfo(this);
        uiInfo.addActor(unitInfo);
        
        scene.addGroup(uiInfo);
    }

    //Called when the cursor selects (not hovers)
    public void cursorSelectSpace(Point position)
    {
        //Get a unit at the spot, if any
        Unit unit = game.getMap().getUnitAtPosition(position.getX(), position.getY());
        
        //Check what the cursor was doing
        switch (cursor.getStatus())
        {
            case Cursor.STATE_SELECTING:
                switch (cursor.getTask())
                {
                    case Cursor.TASK_NONE:
                        if (unit != null && unit.getPlayer() == game.getCurrentPlayer() && unit.isUsable())
                        {
                            //Highlight all movable spots.
                            //getUnitMovementRange(unit);

                            //Start moving the unit
                            cursor.setSelectedUnit(unit);
                            cursor.setStatus(Cursor.STATE_MOVING);
                        }
                        else
                        {
                            //Empty spot or other player's unit? Show the game.getMap() menu
                            MapMenu menu = new MapMenu(position.getScaledCopy(game.getMap().getTileSize()), this, game);
                            menu.show();
                        }
                        break;
                    case Cursor.TASK_ATTACKUNIT:
                        Point point = cursor.getSelected();
                        Unit attacker = game.getMap().getUnitAtPosition(point.getX(), point.getY());
                        game.toBattle(attacker, unit);
                        attacker.setStatus(Unit.UNUSABLE);
                        cursor.setTask(Cursor.TASK_NONE);
                        cursorHoverSpace(position);
                        break;
                }
                break;
            case Cursor.STATE_MOVING:
                //Move the unit
                unit = game.getMap().getUnitAtPosition(cursor.getSelected().getX(), cursor.getSelected().getY());
                unit.setPosition(new Point(cursor.getDestinationX(), cursor.getDestinationY()));
                unit.setPathToFollow(cursor.getPath());
                UnitMenu menu = new UnitMenu(position.getScaledCopy(game.getMap().getTileSize()), this, game, unit);
                menu.show();
                highlightedSpaces.removeAll();
                cursor.startSelecting();
                break;
        }
    }
    
    //Happens when the user hovers over a space
    public void cursorHoverSpace(Point position)
    {
        //If the cursor is moving...
        if (cursor.getStatus() == Cursor.STATE_MOVING)
        {
            //Set up a path from to this spot (the arrows)
            cursor.cachePath(position);
        }
        else
        {
            //It's selecting...
            switch (cursor.getTask())
            {
                case Cursor.TASK_NONE:
                    //Not doing anything? Show a unit's range
                    position = cursor.getDestination();

                    Unit unit = game.getMap().getUnitAtPosition(position.getX(), position.getY());

                    highlightedSpaces.removeAll();

                    if (unit == null || !unit.isUsable())
                        return;

                    //We want to highlight the unit's movement range
                    Hashtable<Point, ColourActor> movementPoints = getUnitMovementRange(unit);
                    getUnitAttackPoints(unit, movementPoints.keySet());
                    break;
                case Cursor.TASK_ATTACKUNIT:
                    
                    break;
            }
        }
    }
    
    //Gets every point that a unit can attack from, excluding the points they can move to
    public Hashtable<Point, ColourActor> getUnitAttackPoints(Unit unit, Set<Point> movementPoints)
    {
        Hashtable<Point, ColourActor> attackSquares = new Hashtable<Point, ColourActor>();
        WeaponItem weapon = unit.getEquippedWeapon();
        
        //Don't bother checking if they don't have a weapon
        if (weapon != null)
        {
            for (Point point : movementPoints)
            {
                Bag<Point> attackPoints = getUnitAttackPoints(unit, point);
                for (Point attackPoint : attackPoints)
                {
                    if (!movementPoints.contains(attackPoint) && !attackSquares.containsKey(attackPoint))
                    {
                        ColourActor square = new ColourActor(attackPoint.getScaledCopy(game.getMap().getTileSize()), new Size(game.getMap().getTileSize(), game.getMap().getTileSize()), getAttackColour(unit));
                        attackSquares.put(attackPoint, square);
                        getHighlightedSpaces().addActor(square);
                    }
                }

            }
        }
        
        return attackSquares;
    }
    
    // Get the points a unit can attack at from a specific point
    public Bag<Point> getUnitAttackPoints(Unit unit, Point point)
    {
        Bag<Point> attackPoints = getPointsInRange(unit.getEquippedWeapon(), point.getX(), point.getY(), unit.getEquippedWeapon().getWeapon().getStats().getRange());
        
        Bag<Point> returnPoints = new Bag<Point>();
        
        for (Point attackPoint : attackPoints)
        {
            if (!attackPoint.equals(unit.getPosition()))
            {
                Unit newUnit = game.getMap().getUnitAtPosition(attackPoint.getX(), attackPoint.getY());

                if (game.getMap().getTile(attackPoint).getMovementCost(UnitType.ALL) != -1 && (newUnit == null || newUnit.getPlayer() != unit.getPlayer()))
                    returnPoints.add(attackPoint);
            }
            else
                attackPoints.remove(attackPoint);
        }
        
        return returnPoints;
    }
    
    // Get the range a unit can move
    public Hashtable<Point, ColourActor> getUnitMovementRange(Unit unit)
    {
        //Brute force it in the area movement*2 x movement*2 centered around the unit
        Hashtable<Point, ColourActor> moveSquares = new Hashtable<Point, ColourActor>();
       
        Bag<Point> movePoints = getPointsInRange(
            unit,
            unit.getPosition().getX(),
            unit.getPosition().getY(),
            new Range(0, unit.getCharacter().getMovement()));
        
        // Create a coloured square at each point
        for (Point point : movePoints)
        {
            ColourActor square = new ColourActor(point.getScaledCopy(game.getMap().getTileSize()), new Size(game.getMap().getTileSize(), game.getMap().getTileSize()), getMovementColour(unit));
            moveSquares.put(point, square);
            getHighlightedSpaces().addActor(square);
        }
        
        return moveSquares;
    }
    
    // Generic function that gets all points within a certain range
    public Bag<Point> getPointsInRange(Mover mover, int x, int y, Range range)
    {
        boolean isItem = (mover instanceof Item ? true : false);
        int minX;
        int minY;
        int maxX;
        int maxY;
        Bag<Point> points = new Bag<Point>();
        AStarCostablePathFinder pathFinder = new AStarCostablePathFinder(
            game.getMap(),
            range.getMaximum(),
            range,
            isItem);
        
        minX = x - range.getMaximum();
        maxX = x + range.getMaximum();
        minY = y - range.getMaximum();
        maxY = y + range.getMaximum();
        
        // Check whether the X is invalid, or out of range of the map
        if (minX < 0)
            minX = 0;
        else if (maxX > game.getMap().getSize().getWidth() - 1)
            maxX = game.getMap().getSize().getWidth() - 1;
        if (minY < 0)
            minY = 0;
        else if (maxY > game.getMap().getSize().getHeight() - 1)
            maxY = game.getMap().getSize().getHeight() - 1;
        
        //Check everything within the square range of their range
        for (int xPos = minX; xPos <= maxX; xPos++)
        {
            for (int yPos = minY; yPos <= maxY; yPos++)
            {
                Path path = pathFinder.findPath(mover, x, y, xPos, yPos);
                if (path != null)
                {
                    Point point = new Point(xPos, yPos);

                    points.add(point);
                }
            }
        }
        
        return points;
    }
    
    public Color getAttackColour(Unit unit)
    {
        if (unit.getPlayer() == game.getCurrentPlayer())
            return OWN_ATTACK_COLOUR;
        else
            return ENEMY_ATTACK_COLOUR;
    }
    
    public Color getMovementColour(Unit unit)
    {
        if (unit.getPlayer() == game.getCurrentPlayer())
            return OWN_MOVEMENT_COLOUR;
        else
            return ENEMY_MOVEMENT_COLOUR;
    }
    
    //Checks if the game or turn is over
    public void checkForEndOfTurn()
    {
        //First check if someone's won yet, meaning they have no units left
        int stillAlive = 0;
        Player winner = null;
        for (Player player : game.getPlayers())
        {
            if (player.getUnits().size() > 0)
            {
                winner = player;
                stillAlive++;
            }
        }
        
        if (stillAlive == 1)
        {
            new ShortInformation(this, "Victory for " + winner.getName() + "!");
            return;
        }

        //Now check if the current player has used all their units for this turn
        Player player = game.getCurrentPlayer();
        boolean turnAlive = false;
        
        for (Unit unit : player.getUnits())
        {
            if (unit.getStatus() == Unit.USABLE)
            {
                turnAlive = true;
                break;
            }
        }
        
        if (!turnAlive)
        {
            game.changeTurn();
        }

    }
    
    public void notifyTurnOver()
    {
        new ShortInformation(this, game.getCurrentPlayer().getName() + "'s Turn");
    }
    
    public void render(GameContainer container, StateBasedGame game, Graphics g) throws SlickException
    {
        scene.render(g);
        scene.renderActors(g);
    }

    public void update(GameContainer container, StateBasedGame game, int delta) throws SlickException
    {
        //camera.centerCamera(cursor);
        scene.update(game, delta);
    }
    
    public ActorGroup getUnits()
    {
        return units;
    }

    public Cursor getCursor()
    {
        return cursor;
    }
    
    public ActorGroup getHighlightedSpaces()
    {
        return highlightedSpaces;
    }
}

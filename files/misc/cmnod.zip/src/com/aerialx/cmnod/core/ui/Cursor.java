package com.aerialx.cmnod.core.ui;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.snippets.MoveToDestination;
import com.aerialx.cmnod.core.states.GameSubState;
import com.aerialx.cmnod.core.states.StateInputActor;
import com.aerialx.cmnod.core.units.Unit;
import com.aerialx.cmnod.core.util.pathfinding.AStarCostablePathFinder;
import com.aerialx.cmnod.core.util.transitions.LinearTransition;
import com.aerialx.util.Point;
import com.aerialx.util.Range;
import com.slickset.collision.Box;
import com.slickset.util.Bag;
import java.util.Hashtable;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.util.pathfinding.Path;
import org.newdawn.slick.util.pathfinding.Path.Step;
import org.newdawn.slick.util.pathfinding.heuristics.ManhattanHeuristic;

/**
 * The cursor used to select and manipulate units on the map
 * @author Aaron (AerialX)
 */
public class Cursor extends StateInputActor
{

    //Holds the X and Y as to where the cursor is
    protected int destinationX;
    protected int destinationY;
    //Holds the keys used to move around the map
    protected int keyMoveLeft;
    protected int keyMoveRight;
    protected int keyMoveUp;
    protected int keyMoveDown;
    protected int keySelect;
    // Listens to the keyboard and moves the Cursor around
    protected CursorInputHandler listener;
    // Holds the unit the cursor is selecting
    protected Unit unit;
    // Holds images in case they're moving a unit
    protected Hashtable<Point, Image> images;
    // Holds a point that says where they last selected
    protected Point selected;
    // Holds the path that was used
    protected Path path;
    // Holds what the cursor is currently doing
    protected int task;
    protected Bag<Point> taskPoints;
    protected MoveToDestination moveSnippet;
    
    public static final GameSubState GAME_SUBSTATE = new GameSubState("Cursor");
    public static Image CURSOR_IMAGE;
    public static SpriteSheet ARROW_SHEET;
   
    public final static int MAX_SPEED = 8;
    public static final int STATE_SELECTING = 0;
    public static final int STATE_MOVING = 1;
    public static final int TASK_NONE = 0;
    public static final int TASK_ATTACKUNIT = 1;
    private static final int DIRECTION_UP = 1;
    private static final int DIRECTION_DOWN = 2;
    private static final int DIRECTION_LEFT = 3;
    private static final int DIRECTION_RIGHT = 4;
    private static final int ARROW_END = 0;
    private static final int ARROW_START = 1;
    private static final int ARROW_STRAIGHT = 2;
    private static final int ARROW_TURN = 3;
    
    public Cursor(Game game) throws SlickException
    {
        this(game, Input.KEY_SPACE, Input.KEY_LEFT, Input.KEY_RIGHT, Input.KEY_UP, Input.KEY_DOWN);
    }

    public Cursor(Game game, int keySelect, int keyMoveLeft, int keyMoveRight, int keyMoveUp, int keyMoveDown) throws SlickException
    {
        super(getCursorImages(), 0, 0, new Box(CURSOR_IMAGE.getWidth(), CURSOR_IMAGE.getHeight()), 1, false, game, game.getGameState(), Cursor.GAME_SUBSTATE);

        moveSnippet = new MoveToDestination(this, new LinearTransition(), 0.007F);
        
        addSnippet(moveSnippet);
        
        this.keyMoveLeft = keyMoveLeft;
        this.keyMoveRight = keyMoveRight;
        this.keyMoveUp = keyMoveUp;
        this.keyMoveDown = keyMoveDown;
        this.keySelect = keySelect;

        this.listener = new CursorInputHandler(this);
        
        this.setStatus(STATE_SELECTING);
        this.task = TASK_NONE;

        game.getGameState().getStateBasedGame().getContainer().getInput().addListener(listener);
    }

    public static Animation[] getCursorImages() throws SlickException
    {
        if (CURSOR_IMAGE == null)
        {
            CURSOR_IMAGE = new Image("res/cursor.gif");
        }
        
        if (ARROW_SHEET == null)
        {
            ARROW_SHEET = new SpriteSheet("res/Arrows.png", 32, 32);
        }

        Animation[] animations = new Animation[5];
        
        Animation animation = new Animation();
        animation.addFrame(CURSOR_IMAGE, Integer.MAX_VALUE);
        animations[0] = animation;
        
        for (int i = 0; i < ARROW_SHEET.getHorizontalCount(); i++)
        {
            animation = new Animation();
            animation.addFrame(ARROW_SHEET.getSprite(0, i), Integer.MAX_VALUE);
            animations[i + 1] = animation;
        }
        
        return animations;
    }

    public void update(StateBasedGame game, int delta)
    {
        super.update(game, delta);
    }

    @Override
    protected void selectAnimation(int oldStatus, int oldDirection, int newStatus, int newDirection)
    {
        if (newStatus == STATE_SELECTING)
            setAnimation(0);
    }

    @Override
    public void render(Graphics g, float x, float y)
    {
        if (getStatus() == STATE_SELECTING)
        {
            super.render(g, x, y);
        }
        else if (getStatus() == STATE_MOVING)
        {
            if (images == null)
                cachePath(getDestination());
            
            if (images == null)
            {
                super.render(g, x, y);
            }
            else
            {
                for (Point point : images.keySet())
                {
                    Point screenPoint = getScreenPoint(point.getScaledCopy(game.getMap().getTileSize()));
                    Rectangle clip = getClipper();
                    g.drawImage(images.get(point), clip.getX() + screenPoint.getX(), clip.getY() + screenPoint.getY());
                }
            }
        }
    }
	
    private Rectangle getClipper()
    {
        return gameState.getScene().getLayer().getViewport().getClip();
    }
    
	private Point getScreenPoint(Point point)
	{
		return new Point((int)point.getX() - (int)getLayer().getViewport().getX(), (int)point.getY() - (int)getLayer().getViewport().getY());
	}
    
    private int getDirection(Step step1, Step step2)
    {
        int dx = step1.getX() - step2.getX();
        int dy = step1.getY() - step2.getY();
        
        if (dx != 0)
        {
            if (dx > 0)
                return DIRECTION_LEFT;
            else
                return DIRECTION_RIGHT;
        }
        else if (dy != 0)
        {
            if (dy > 0)
                return DIRECTION_UP;
            else
                return DIRECTION_DOWN;
        }
        else
            return 0;
    }
    
    public void cachePath(Point position)
    {
        images = null;
        
        if (getStatus() != STATE_MOVING)
            return;
        
        Unit newUnit = game.getMap().getUnitAtPosition(destinationX, destinationY);
        if (newUnit != getSelectedUnit() && newUnit != null && newUnit.getPlayer() == unit.getPlayer())
        {
            setDestination(position);
            
            return;
        }
        
        Range range = new Range(1, unit.getCharacter().getMovement());
        
        AStarCostablePathFinder finder = new AStarCostablePathFinder(game.getMap(), range.getMaximum(), range, false, new ManhattanHeuristic(1));
        
        Path oldPath = path;
        path = finder.findPath(unit, unit.getPosition().getX(), unit.getPosition().getY(), destinationX, destinationY);
        
        Step previousStep = null;
        
        if (path == null)
        {
            if (newUnit != getSelectedUnit())
            {
                path = oldPath;
                setDestination(position);
            }
            return;
        }
            
        images = new Hashtable<Point, Image>();
        
        for (int i = 0; i < path.getLength(); i++)
        {
            Step step = path.getStep(i);
            Step nextStep = null;
            Image image = null;
            Point point = new Point(step.getX(), step.getY());

            if (i < path.getLength() - 1)
                nextStep = path.getStep(i + 1);

            if (previousStep == null)
            {
                //Start
                image = ARROW_SHEET.getSprite(ARROW_START, 0);
                int direction = getDirection(step, nextStep);
                
                if (direction == DIRECTION_DOWN)
                    image.rotate(180);
                else if (direction == DIRECTION_RIGHT)
                    image.rotate(90);
                else if (direction == DIRECTION_LEFT)
                    image.rotate(270);
            }
            else if (nextStep == null)
            {
                //End
                image = ARROW_SHEET.getSprite(ARROW_END, 0);
                int direction = getDirection(previousStep, step);

                if (direction == DIRECTION_DOWN)
                    image.rotate(180);
                else if (direction == DIRECTION_LEFT)
                    image.rotate(270);
                else if (direction == DIRECTION_RIGHT)
                    image.rotate(90);
            }
            else if (isStraight(previousStep, nextStep))
            {
                //Straight
                image = ARROW_SHEET.getSprite(ARROW_STRAIGHT, 0);
                int direction = getDirection(step, nextStep);

                if (direction == DIRECTION_LEFT || direction == DIRECTION_RIGHT)
                    image.rotate(90);
            }
            else
            {
                //Turn
                image = ARROW_SHEET.getSprite(ARROW_TURN, 0);
                int directionPrevious = getDirection(step, previousStep);
                int directionNext = getDirection(step, nextStep);

                if (directionNext == DIRECTION_DOWN || directionPrevious == DIRECTION_DOWN)
                    image = image.getFlippedCopy(false, true);
                
                if (directionPrevious == DIRECTION_RIGHT || directionNext == DIRECTION_RIGHT)
                    image = image.getFlippedCopy(true, false);
            }

            images.put(point, image);
            
            previousStep = step;
        }
    }
    
    public void select()
    {
        game.getGameState().cursorSelectSpace(new Point(destinationX, destinationY));
        selected = new Point(destinationX, destinationY);
    }
    
    public void hover(int x, int y)
    {
        game.getGameState().cursorHoverSpace(new Point(x, y));
    }
    
    private boolean isStraight(Step step1, Step step2)
    {
        return step1.getX() == step2.getX() || step1.getY() == step2.getY();
    }
    
    public void startSelecting()
    {
        setStatus(STATE_SELECTING);
        this.path = null;
        this.images = null;
    }
    
    protected void refreshMoveSnippet()
    {
        moveSnippet.getDestinations().clear();
        moveSnippet.getDestinations().add(getDestination().getScaledCopy(game.getMap().getTileSize()));
        moveSnippet.setPreviousPosition(new Point((int)getX(), (int)getY()));
    }
    
    public Point getDestination()
    {
        return new Point(destinationX, destinationY);
    }
    
    public void handleInput(StateBasedGame game, int delta)
    {

    }

    public void setDestination(Point point)
    {
        setDestinationX(point.getX());
        setDestinationY(point.getY());
        
        refreshMoveSnippet();
    }
    
    public Bag<Point> getTaskPoints()
    {
        return taskPoints;
    }

    public void setTaskPoints(Bag<Point> taskPoints)
    {
        this.taskPoints = taskPoints;
    }
    
    public int getTask()
    {
        return task;
    }

    public void setTask(int task)
    {
        this.task = task;
    }
    
    public Path getPath()
    {
        return path;
    }
    
    public Point getSelected()
    {
        return selected;
    }
    
    public int getDestinationX()
    {
        return destinationX;
    }

    public int getDestinationY()
    {
        return destinationY;
    }

    public void setDestinationX(int destinationX)
    {
        this.destinationX = destinationX;
        
        refreshMoveSnippet();
    }

    public void setDestinationY(int destinationY)
    {
        this.destinationY = destinationY;
        
        refreshMoveSnippet();
    }

    public Game getGame()
    {
        return super.getGame();
    }

    public int getKeyMoveDown()
    {
        return keyMoveDown;
    }

    public int getKeyMoveLeft()
    {
        return keyMoveLeft;
    }

    public int getKeyMoveRight()
    {
        return keyMoveRight;
    }

    public int getKeyMoveUp()
    {
        return keyMoveUp;
    }

    public int getKeySelect()
    {
        return keySelect;
    }

    public void setSelectedUnit(Unit selectedUnit)
    {
        this.unit = selectedUnit;
    }

    public Unit getSelectedUnit()
    {
        return unit;
    }

    public MoveToDestination getMoveSnippet()
    {
        return moveSnippet;
    }
}

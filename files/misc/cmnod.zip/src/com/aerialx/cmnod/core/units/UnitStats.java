package com.aerialx.cmnod.core.units;

/**
 * Information about the stats of a unit.
 * @author lindaaro242
 */
public class UnitStats
{

    protected int health;
    protected int strength;
    protected int defence;
    protected int magic;
    protected int resistance;
    protected int luck;
    protected int speed;
    protected int skill;

    public UnitStats()
    {
        this(0, 0, 0, 0, 0, 0, 0, 0);
    }
    
    public UnitStats(int health, int strength, int defence, int magic, int resistance, int luck, int speed, int skill)
    {
        this.health = health;
        this.strength = strength;
        this.defence = defence;
        this.magic = magic;
        this.resistance = resistance;
        this.luck = luck;
        this.speed = speed;
        this.skill = skill;
    }

    public static UnitStats add(UnitStats stats1, UnitStats stats2)
    {
        UnitStats ret = new UnitStats();
        
        ret.add(stats1);
        ret.add(stats2);
        
        return ret;
    }
    
    public void add(UnitStats stats)
    {
        setHealth(getHealth() + stats.getHealth());
        setStrength(getStrength() + stats.getStrength());
        setDefence(getDefence() + stats.getDefence());
        setMagic(getMagic() + stats.getMagic());
        setResistance(getResistance() + stats.getResistance());
        setLuck(getLuck() + stats.getLuck());
        setSpeed(getSpeed() + stats.getSpeed());
        setSkill(getSkill() + stats.getSkill());
    }
    
    public UnitStats copy()
    {
        return new UnitStats(
            getHealth(),
            getStrength(),
            getDefence(),
            getMagic(),
            getResistance(),
            getLuck(),
            getSpeed(),
            getSkill()
        );
    }
    
    public int getHealth()
    {
        return health;
    }

    public void setHealth(int health)
    {
        this.health = health;
    }
    
    public int getDefence()
    {
        return defence;
    }

    public void setDefence(int val)
    {
        this.defence = val;
    }

    public int getLuck()
    {
        return luck;
    }

    public void setLuck(int val)
    {
        this.luck = val;
    }

    public int getMagic()
    {
        return magic;
    }

    public void setMagic(int val)
    {
        this.magic = val;
    }

    public int getResistance()
    {
        return resistance;
    }

    public void setResistance(int val)
    {
        this.resistance = val;
    }

    public int getSkill()
    {
        return skill;
    }

    public void setSkill(int val)
    {
        this.skill = val;
    }

    public int getSpeed()
    {
        return speed;
    }

    public void setSpeed(int val)
    {
        this.speed = val;
    }

    public int getStrength()
    {
        return strength;
    }

    public void setStrength(int val)
    {
        this.strength = val;
    }
}


package com.aerialx.cmnod.core;

import com.aerialx.cmnod.core.units.Unit;
import com.slickset.util.Bag;
import org.newdawn.slick.Color;
/**
 * Represents one player of the game.
 * @author Aaron Lindsay
 */
public class Player
{

    protected String name;
    protected Bag<Unit> units;
    protected Game game;
    protected Color colour;

    public Player(String name, Game game, Color colour)
    {
        this.name = name;
        this.game = game;
        this.colour = colour;
        this.units = new Bag<Unit>();
    }
    
    public void playerTurn()
    {
    }

    public Color getColour()
    {
        return colour;
    }

    public void setColour(Color val)
    {
        this.colour = val;
    }

    public Game getGame()
    {
        return game;
    }

    public void setGame(Game val)
    {
        this.game = val;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String val)
    {
        this.name = val;
    }

    public Bag<Unit> getUnits()
    {
        return units;
    }

    public void setUnits(Bag<Unit> val)
    {
        this.units = val;
    }
}


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.aerialx.cmnod.core.util;

/**
 * Defines a transition from one point to another; used to move things.
 * @author Aaron Lindsay
 */
public abstract class Transition
{
    public abstract float getValue(float percent);
    
    public float getValue(float length, float percent)
    {
        return getValue(percent) * length;
    }
    
    public float getValue(float start, float finish, float percent)
    {
        return start + getValue(finish - start, percent);
    }
}

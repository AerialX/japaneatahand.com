/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.aerialx.cmnod.core.util.xml;

import com.aerialx.cmnod.core.units.UnitClass;
import com.aerialx.cmnod.core.units.UnitStats;
import com.aerialx.cmnod.core.units.UnitType;
import com.aerialx.cmnod.units.GroundUnit;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Hashtable;
import javax.xml.xpath.*;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 * Loads and maintains unit classes from an XML definition
 * @author Aaron Lindsay
 */
public class XmlClasses {
    public static Hashtable<String, UnitClass> loaded;
    
    public static void loadClasses()
    {
        loaded = new Hashtable<String, UnitClass>();
        
        File directory = new File("res/Definitions/Classes");
        
        File[] files = directory.listFiles();
        
        for (File file : files) {
            InputSource inputSource = null;
            XPath xPath;
            NodeList nodes = null;

            XPathFactory factory = XPathFactory.newInstance();

            xPath = factory.newXPath();
            
            try {
                inputSource = new InputSource(new FileInputStream(file.getPath()));
            } catch (FileNotFoundException ex) { }
            
            try {
                nodes = (NodeList)xPath.evaluate("/class", inputSource, XPathConstants.NODESET);
            } catch (XPathExpressionException ex) { }
            
            for (int i = 0; i < nodes.getLength(); i++)
            {
                Node node = nodes.item(i);
                NodeList list = node.getChildNodes();
                String cName = null;
                UnitType cType = null;
                UnitStats cStats = null;
                int cMovement = 0;
                float cMoveSpeed = 0;
                
                for (int j = 0; j < list.getLength(); j++) {
                    node = list.item(j);

                    if (node.getNodeName().equalsIgnoreCase("name"))
                    {
                        cName = node.getTextContent().trim();
                    }
                    else if (node.getNodeName().equalsIgnoreCase("type"))
                    {
                        //TODO when XmlTypes is complete
                        cType = GroundUnit.INSTANCE;
                    }
                    else if (node.getNodeName().equalsIgnoreCase("movement"))
                    {
                        cMovement = Integer.parseInt(node.getTextContent().trim());
                    }
                    else if (node.getNodeName().equalsIgnoreCase("stats"))
                    {
                        cStats = new UnitStats();
                        NamedNodeMap attributes = node.getAttributes();
                        cStats.setHealth(Integer.parseInt(attributes.getNamedItem("health").getNodeValue()));
                        cStats.setStrength(Integer.parseInt(attributes.getNamedItem("strength").getNodeValue()));
                        cStats.setDefence(Integer.parseInt(attributes.getNamedItem("defence").getNodeValue()));
                        cStats.setMagic(Integer.parseInt(attributes.getNamedItem("magic").getNodeValue()));
                        cStats.setResistance(Integer.parseInt(attributes.getNamedItem("resistance").getNodeValue()));
                        cStats.setLuck(Integer.parseInt(attributes.getNamedItem("luck").getNodeValue()));
                        cStats.setSpeed(Integer.parseInt(attributes.getNamedItem("speed").getNodeValue()));
                        cStats.setSkill(Integer.parseInt(attributes.getNamedItem("skill").getNodeValue()));
                    }
                    else if (node.getNodeName().equalsIgnoreCase("movespeed"))
                    {
                        cMoveSpeed = Float.parseFloat(node.getTextContent().trim());
                    }
                }

                UnitClass unitClass = new UnitClass(cName, cType, cMovement, cStats, new UnitStats(), cMoveSpeed);
                
                loaded.put(cName, unitClass);
            }
        }
    }
}

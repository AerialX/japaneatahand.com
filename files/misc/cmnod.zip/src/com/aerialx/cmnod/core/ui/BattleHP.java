package com.aerialx.cmnod.core.ui;

import com.aerialx.cmnod.core.units.Unit;
import com.slickset.Actor;
import com.slickset.collision.Box;
import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.state.StateBasedGame;

/**
 * Used to display a unit's HP when in battle
 * @author Aaron Lindsay
 */
public class BattleHP extends Actor
{
    
    protected Unit unit;
    protected int currentHealth;
    protected int change;
    protected int maxHealth;
    public static int DEFAULT_HEIGHT = 30;
    public static int DEFAULT_WIDTH = 100;
    public static int CHANGE_RATE = 80;
    
    public BattleHP(Unit unit, int x, int y)
    {
        this(unit, new Rectangle(x, y, DEFAULT_WIDTH, DEFAULT_HEIGHT));
        
        this.currentHealth = unit.getHealth();
        this.change = 0;
    }
    
    public BattleHP(Unit unit, Rectangle rect)
    {
        super(null, rect.getX(), rect.getY(), new Box(rect.getWidth(), rect.getHeight()));
        
        this.unit = unit;
    }

    public void update(StateBasedGame game, int delta)
    {
        super.update(game, delta);
        
        change += delta;
        
        maxHealth = unit.getCombinedStats().getHealth();
        
        if (change >= CHANGE_RATE)
        {
            change = 0;
            
            int unitHealth = unit.getHealth();
            
            if (currentHealth != unitHealth)
            {
                int direction = (int)Math.signum(unitHealth - currentHealth);
                
                currentHealth += direction;
            }
        }
    }

    public void render(Graphics g, float x, float y)
    {
        g.setColor(Color.black);
        g.drawString(Integer.toString(currentHealth) + " / " + Integer.toString(maxHealth), x, y);
        
        g.drawRect(x, y + 15, getWidth() + 2, 12);
        g.setColor(Color.red);
        g.fillRect(x + 1, y + 16, (float)currentHealth / (float)maxHealth * getWidth(), 10);
    }
}

/*
 * SlickSet
 * 
 * This source is provided under the terms of the BSD License.
 * 
 * Copyright (c) 2007, Stencyl
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the following 
 * conditions are met:
 * 
 *  * Redistributions of source code must retain the above 
 *    copyright notice, this list of conditions and the 
 *    following disclaimer.
 *  * Redistributions in binary form must reproduce the above 
 *    copyright notice, this list of conditions and the following 
 *    disclaimer in the documentation and/or other materials provided 
 *    with the distribution.
 *  * Neither the name of the SlickSet, Slick nor the names of 
 *    its contributors may be used to endorse or promote products 
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 */
package com.aerialx.cmnod.core.util.tile;

import java.util.ArrayList;

import org.newdawn.slick.Graphics;

/**
 * A layer composed of a standard 2D grid of Tiles.
 * 
 * @author Jonathan Chung
 */
public class AnimatedTileLayer extends AbstractAnimatedTileLayer
{

    protected int tileSize;

    /**
     * Creates a TileLayer given its dimensions.
     * 
     * @param width Width, in tiles
     * @param height Height, in tiles
     * @param tileSize Size of each tile. Width and height are the same.
     */
    public AnimatedTileLayer(int width, int height, int tileSize)
    {
        super(width * tileSize, height * tileSize);

        this.tileSize = tileSize;

        data = new AnimatedTileModel(this, width, height, tileSize);
    }

    /**
     * Render this Layer to the game's graphics context.
     * 
     * @param g The graphics context to render to.
     */
    public void render(Graphics g)
    {
        int width = data.getWidth();
        int height = data.getHeight();

        for (int row = 0; row < height; row++)
        {
            for (int col = 0; col < width; col++)
            {
                AnimatedTile t = data.getTile(col, row, 0);

                if (t != null)
                {
                    t.render(g);
                }
            }
        }
    }

    /**
     * A 2D grid of Tiles.
     * 
     * @author Jonathan Chung
     */
    public class AnimatedTileModel extends AbstractAnimatedTileModel
    {
        //Convention: Rows, Columns
        protected ArrayList<ArrayList<AnimatedTile>> data;
        protected AnimatedTileLayer parent;

        /**
         * Creates a TileLayer given its dimensions. Caller
         * must provide the correct width and height.
         * 
         * @param parent TileLayer
         * @param width Width, in tiles
         * @param height Height, in tiles
         * @param tilesize Size of each tile. Width and height are the same.
         */
        public AnimatedTileModel(AnimatedTileLayer parent, int width, int height, int tilesize)
        {
            super(tileSize, tilesize, 0);

            this.parent = parent;

            data = new ArrayList<ArrayList<AnimatedTile>>(height);

            for (int rows = 0; rows < height; rows++)
            {
                ArrayList<AnimatedTile> row = new ArrayList<AnimatedTile>(width);
                data.add(row);

                for (int cols = 0; cols < width; cols++)
                {
                    row.add(null);
                }
            }
        }

        /**
         * Returns the width of this map in terms of tiles.
         * 
         * @return Map width
         */
        public int getWidth()
        {
            return data.get(0).size();
        }

        /**
         * Returns the height of this map in terms of tiles.
         * 
         * @return Map height
         */
        public int getHeight()
        {
            return data.size();
        }

        /**
         * Has no real meaning since this is a 2D map.
         * 
         * @return 1
         */
        public int getDepth()
        {
            return 1;
        }

        /**
         * Returns the requested tile if it exists.
         * For 2D models. If 3D, z defaults to 0.
         * 
         * @param x x-index of tile
         * @param y y-index of tile
         * 
         * @return Tile, if it exists
         */
        public AnimatedTile getTile(int x, int y)
        {
            return getTile(x, y, 0);
        }

        /**
         * Sets the index in the model to the given tile.
         * For 2D models. If 3D, z defaults to 0.
         * 
         * @param t Tile to set
         * @param x x-index of tile
         * @param y y-index of tile
         */
        public void setTile(AnimatedTile t, int x, int y)
        {
            setTile(t, x, y, 0);
        }

        /**
         * Returns the requested tile if it exists.
         * 
         * @param x x-index of tile
         * @param y y-index of tile
         * @param z z-index of tile
         * 
         * @return Tile, if it exists
         */
        public AnimatedTile getTile(int x, int y, int z)
        {
            if (x < 0 || y < 0 || x >= getWidth() || y >= getHeight())
            {
                return null;
            }

            return data.get(y).get(x);
        }

        /**
         * Sets the index in the model to the given tile.
         * 
         * @param t Tile to set
         * @param x x-index of tile
         * @param y y-index of tile
         * @param z z-index of tile
         */
        public void setTile(AnimatedTile t, int x, int y, int z)
        {
            t.setX(x * getTileWidth());
            t.setY(y * getTileHeight());

            t.setLayer(parent);

            data.get(y).set(x, t);
        }
    }
} 

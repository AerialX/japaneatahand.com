package com.aerialx.cmnod.core.states;

import com.aerialx.cmnod.core.Game;
import com.slickset.AnimatedActor;
import com.slickset.collision.Box;
import com.slickset.collision.DynamicShape;
import org.newdawn.slick.Animation;
import org.newdawn.slick.Image;
import org.newdawn.slick.state.StateBasedGame;

/**
 * An actor that can take focus. Used for UI elements that require user interaction
 * such as a menu.
 * @author Aaron Lindsay
 */
public abstract class StateInputActor extends AnimatedActor
{

    protected GameSubState previousSubState;
    protected GameSubState subState;
    protected BaseState gameState;
    protected Game game;

    public StateInputActor(float x, float y, Game game, BaseState gameState, GameSubState subState)
    {
        this(new Animation[0], x, y, new Box(1, 1), 1.0f, true, game, gameState, subState);
    }

    public StateInputActor(Image image, float x, float y, DynamicShape s, float mass, boolean staticBody, Game game, BaseState gameState, GameSubState subState)
    {
        this(new Animation(new Image[]{image, image}, 10), x, y, s, mass, staticBody, game, gameState, subState);
    }

    public StateInputActor(Animation animation, float x, float y, DynamicShape s, float mass, boolean staticBody, Game game, BaseState gameState, GameSubState subState)
    {
        this(new Animation[]{animation}, x, y, s, mass, staticBody, game, gameState, subState);
    }

    public StateInputActor(Animation[] animations, float x, float y, DynamicShape s, float mass, boolean staticBody, Game game, BaseState gameState, GameSubState subState)
    {
        super(animations, x, y, s, mass, staticBody);

        this.setAnimation(0);

        this.subState = subState;
        this.gameState = gameState;
        this.game = game;

        if (!gameState.getSubStates().contains(subState))
        {
            gameState.getSubStates().add(subState);
        }
    }

    public void update(StateBasedGame game, int delta)
    {
        super.update(game, delta);

        if (isAcceptingInput())
        {
            handleInput(game, delta);
        }
    }

    public abstract void handleInput(StateBasedGame game, int delta);

    public boolean isAcceptingInput()
    {
        return gameState.getCurrentState() == subState;
    }

    public void takeFocus()
    {
        if (!isAcceptingInput())
        {
            previousSubState = gameState.getCurrentState();
            gameState.setCurrentState(subState);
        }
    }
    
    public void releiveFocus()
    {
        if (isAcceptingInput())
        {
            gameState.setCurrentState(previousSubState);
            previousSubState = null;
        }
    }

    protected void selectAnimation(int oldStatus, int oldDirection, int newStatus, int newDirection)
    {
        this.setAnimation(0);
    }

    public GameSubState getPreviousSubState()
    {
        return previousSubState;
    }

    public GameSubState getSubState()
    {
        return subState;
    }

    public void setSubState(GameSubState subState)
    {
        this.subState = subState;
    }

    public BaseState getGameState()
    {
        return gameState;
    }

    public void setGameState(BaseState gameState)
    {
        this.gameState = gameState;
    }

    public Game getGame()
    {
        return game;
    }

    public void setGame(Game game)
    {
        this.game = game;
    }
}

package com.aerialx.cmnod.core.units;

import com.aerialx.cmnod.core.Game;
import com.aerialx.cmnod.core.Player;
import com.aerialx.cmnod.core.items.Inventory;
import com.aerialx.cmnod.core.items.EquippableItem;
import com.aerialx.cmnod.core.items.Item;
import com.aerialx.cmnod.core.items.WeaponItem;
import com.aerialx.cmnod.core.items.WeaponType;
import com.aerialx.cmnod.core.util.NlrudAnimationSelector;
import com.aerialx.util.Point;
import com.slickset.AnimatedActor;
import com.slickset.collision.Box;
import com.slickset.util.Bag;
import java.util.Hashtable;
import java.util.Iterator;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.util.pathfinding.Mover;
import org.newdawn.slick.util.pathfinding.Path;
import org.newdawn.slick.util.pathfinding.Path.Step;

/**
 * An instance of a unit in the game and on the map.
 * @author lindaaro242
 */
public class Unit extends AnimatedActor implements Mover
{

    public static final int USABLE = 0;
    public static final int UNUSABLE = 1;
    protected Character character;
    protected int health;
    protected Bag<UnitStats> boosts;
    protected Inventory<Item> items;
    protected Inventory<WeaponItem> weapons;
    protected Bag<EquippableItem> equippedItems;
    protected Hashtable<WeaponType, Integer> skills;
    protected int experience;
    protected Player player;
    protected Hashtable<WeaponType, Integer> weaponExperience;
    protected Point position;
    protected Path path;
    protected int stepIndex;

    public Unit(Character character, Point position, Player player)
    {
        super(character.getMapAnimations(),
            position.getX() * player.getGame().getMap().getTileSize(),
            position.getY() * player.getGame().getMap().getTileSize(),
            new Box(character.getSize().getWidth(), character.getSize().getHeight()),
            1.0F,
            false
        );
        
        this.setStatus(USABLE);
        
        this.character = character;
        this.position = position;
        this.player = player;
        
        this.boosts = new Bag<UnitStats>();
        this.items = new Inventory<Item>(4);
        this.weapons = new Inventory<WeaponItem>(4);
        this.equippedItems = new Bag<EquippableItem>();
        this.skills = new Hashtable<WeaponType, Integer>();
        this.stepIndex = -1;
        this.health = character.getUnitStats().getHealth();
        
        initializeSkills();
        
        setAnimation(NlrudAnimationSelector.NEUTRAL);
    }
    
    public WeaponItem getEquippedWeapon()
    {
        for (Iterator<EquippableItem> it = equippedItems.iterator(); it.hasNext();)
        {
            EquippableItem item = it.next();
            
            if (item instanceof WeaponItem)
                return (WeaponItem)item;
        }
        
        return null;
    }
    
    public void initializeSkills(boolean preserve)
    {
        if (!preserve)
            skills.clear();
        
        for (Iterator<WeaponType> it = ((Game)getPlayer().getGame()).getWeaponTypes().values().iterator(); it.hasNext();)
        {
            WeaponType weapon = it.next();
            
            if (!preserve || (preserve && !skills.containsKey(weapon)))
                skills.put(weapon, 0);
        }
    }
    
    public void initializeSkills()
    {
        initializeSkills(false);
    }

    @Override
    public void update(StateBasedGame game, int delta)
    {
        super.update(game, delta);
        
        if (stepIndex == -1 || path == null || path.getLength() == stepIndex)
            return;
        
        Step step = path.getStep(stepIndex);
        
        Point mapPosition = new Point(step.getX(), step.getY()).getScaledCopy(player.getGame().getMap().getTileSize());
        
        if ((float)mapPosition.getX() != getX() || (float)mapPosition.getY() != getY())
        {
            float dx;
            float dy;
            
            int direction;
            
            dx = mapPosition.getX() - getX();
            
            direction = (int)Math.signum(dx);
            dx = Math.abs(dx);
            
            dx -= character.getMovementSpeed() * (float)delta;
            if (dx < 0)
                dx = 0;
            
            setX(mapPosition.getX() - dx * direction);
            
            if (direction != 0)
                setDirection((direction > 0 ? AnimatedActor.RIGHT : AnimatedActor.LEFT));
            
            dy = mapPosition.getY() - getY();
            
            direction = (int)Math.signum(dy);
            dy = Math.abs(dy);
            
            dy -= character.getMovementSpeed() * (float)delta;
            if (dy < 0)
                dy = 0;
            
            setY(mapPosition.getY() - dy * direction);
            
            if (direction != 0)
                setDirection((direction > 0 ? AnimatedActor.DOWN : AnimatedActor.UP));
        }
        else
        {
            stepIndex++;
            
            if (stepIndex == path.getLength())
            {
                setDirection(Unit.NONE);
                
                path = null;
                stepIndex = -1;
            }
        }
    }

    @Override
    public void render(Graphics g, float x, float y)
    {
        //super.render(g, x, y);
        g.drawImage(getCurrentAnimation().getCurrentFrame(), x, y);
    }
    
    public void die()
    {
        player.getUnits().remove(this);
        player.getGame().getGameState().getUnits().removeActor(this);
        health = 0;
    }
    
    public boolean isDead()
    {
        return health <= 0;
    }
    
    protected void selectAnimation(int oldStatus, int oldDirection, int newStatus, int newDirection)
    {
        try
        {            
            setAnimation(character.getMapAnimationIndex(newDirection, newStatus));
        } catch (Exception ex) { }
    }

    public UnitStats getCombinedStats()
    {
        UnitStats ret = character.getUnitStats().copy();
        
        for (UnitStats unitStats : boosts)
        {
            ret.add(unitStats);
        }

        //Terrain bonus:
        ret.add(player.getGame().getMap().getTile(position.getX(), position.getY()).getTerrainBonus(character.getUnitClass().getUnitType()));
        
        return ret;
    }
    
    public boolean isUsable()
    {
        return getStatus() == USABLE;
    }
    
    /*
    public Animation getCurrentAnimation()
    {
        return character.getMapAnimations(getDirection(), getStatus());
    }
    */

    public void setPathToFollow(Path path)
    {
        stepIndex = 0;
        this.path = path;
    }
    
    public Point getPosition()
    {
        return position;
    }

    public void setPosition(Point position)
    {
        this.position = position;
    }
    
    public Bag<UnitStats> getBoosts()
    {
        return boosts;
    }

    public void setBoosts(Bag<UnitStats> val)
    {
        this.boosts = val;
    }

    public Character getCharacter()
    {
        return character;
    }

    public void setCharacter(Character val)
    {
        this.character = val;
    }

    public Bag<EquippableItem> getEquippedItems()
    {
        return equippedItems;
    }

    public void setEquippedItems(Bag<EquippableItem> val)
    {
        this.equippedItems = val;
    }

    public int getExperience()
    {
        return experience;
    }

    public void setExperience(int val)
    {
        this.experience = val;
    }

    public int getHealth()
    {
        return health;
    }

    public void setHealth(int val)
    {
        this.health = val;
        
        if (isDead())
            die();
    }

    public Inventory getItems()
    {
        return items;
    }

    public void setItems(Inventory val)
    {
        this.items = val;
    }

    public Player getPlayer()
    {
        return player;
    }

    public void setPlayer(Player val)
    {
        this.player = val;
    }

    public Hashtable<WeaponType, Integer> getSkills()
    {
        return skills;
    }

    public void setSkills(Hashtable<WeaponType, Integer> val)
    {
        this.skills = val;
    }

    public Hashtable<WeaponType, Integer> getWeaponExperience()
    {
        return weaponExperience;
    }

    public void setWeaponExperience(Hashtable<WeaponType, Integer> val)
    {
        this.weaponExperience = val;
    }

    public Inventory getWeapons()
    {
        return weapons;
    }

    public void setWeapons(Inventory val)
    {
        this.weapons = val;
    }
}


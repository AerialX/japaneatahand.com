/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.aerialx.cmnod.core;

import org.newdawn.slick.Color;

/**
 *
 * @author lindaaro242
 */
public class AIPlayer extends Player {

    public AIPlayer(String name, Game game, Color colour)
    {
        super(name, game, colour);
    }
    
    public void playerTurn()
    {
        
    }
}


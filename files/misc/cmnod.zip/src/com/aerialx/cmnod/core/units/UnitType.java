package com.aerialx.cmnod.core.units;

/**
 * Describes a type of unit.
 * @author Aaron Lindsay
 */
public class UnitType
{

    public static final UnitType ALL = new UnitType("All Units");
    
    protected String name;

    public UnitType(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String val)
    {
        this.name = val;
    }
}


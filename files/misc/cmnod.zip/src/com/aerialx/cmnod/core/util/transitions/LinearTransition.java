package com.aerialx.cmnod.core.util.transitions;

import com.aerialx.cmnod.core.util.Transition;

/**
 * A basic transition that is defined as a linear graph where x = y
 * @author Aaron Lindsay
 */
public class LinearTransition extends Transition
{

    public float getValue(float percent)
    {
        return percent;
    }

}

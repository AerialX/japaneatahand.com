package com.aerialx.cmnod.core.items;

import com.aerialx.util.Range;

/**
 * Holds information about a weapon.
 * @author Aaron Lindsay
 */
public class WeaponStats
{

    protected int level;
    protected int might;
    protected int hit;
    protected int critical;
    protected int weight;
    protected Range range;

    public WeaponStats()
    {
        this(0, 0, 0, 0, 0, new Range(0, 0));
    }

    public WeaponStats(int level, int might, int hit, int critical, int weight, Range range)
    {
        this.level = level;
        this.might = might;
        this.hit = hit;
        this.critical = critical;
        this.weight = weight;
        this.range = range;
    }

    public int getCritical()
    {
        return critical;
    }

    public void setCritical(int val)
    {
        this.critical = val;
    }

    public int getHit()
    {
        return hit;
    }

    public void setHit(int val)
    {
        this.hit = val;
    }

    public int getLevel()
    {
        return level;
    }

    public void setLevel(int val)
    {
        this.level = val;
    }

    public int getMight()
    {
        return might;
    }

    public void setMight(int val)
    {
        this.might = val;
    }

    public Range getRange()
    {
        return range;
    }

    public void setRange(Range val)
    {
        this.range = val;
    }

    public int getWeight()
    {
        return weight;
    }

    public void setWeight(int val)
    {
        this.weight = val;
    }
}


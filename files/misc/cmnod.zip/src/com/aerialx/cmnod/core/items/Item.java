package com.aerialx.cmnod.core.items;

import org.newdawn.slick.util.pathfinding.Mover;

/**
 * Represents an instance of an item that a unit holds.
 * @author Aaron Lindsay
 */
public class Item implements Mover
{

    protected String name;
    protected String description;

    public Item(String name, String description)
    {
        this.name = name;
        this.description = description;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String val)
    {
        this.description = val;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String val)
    {
        this.name = val;
    }
}


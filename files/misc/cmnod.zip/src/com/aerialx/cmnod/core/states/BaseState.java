package com.aerialx.cmnod.core.states;

import com.aerialx.cmnod.core.Game;
import com.slickset.ActorGroup;
import com.slickset.Camera;
import com.slickset.Scene;
import com.slickset.util.Bag;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.state.BasicGameState;
import org.newdawn.slick.state.StateBasedGame;

/**
 * BaseState is the basic state for all game states... Used to set up a SlickSet
 * scene and get the UI set up (GameSubStates and such)
 * @author Aaron Lindsay
 */
public abstract class BaseState extends BasicGameState
{
    protected Bag<GameSubState> subStates;
    protected GameSubState currentState;
    protected StateBasedGame stateBasedGame;
    protected ActorGroup menus;
    protected Scene scene;
    protected Camera camera;
    protected Game game;

    public BaseState(Game game)
    {
        this.game = game;
        this.subStates = new Bag<GameSubState>();
        
        this.menus = new ActorGroup("Menus");
    }

    public void init(GameContainer container, StateBasedGame sbg) throws SlickException
    {
        this.stateBasedGame = sbg;

        scene = new Scene(sbg);
        
        camera = new Camera(0, 0);
        scene.setCamera(camera);
        
        postInit(container, sbg);
        
        scene.addGroup(menus);
    }
    
    public void postInit(GameContainer container, StateBasedGame sbg) throws SlickException
    {
        
    }
    
    public void keyPressed(int key, char c) 
    {
        super.keyPressed(key, c);

        if(key == Input.KEY_ESCAPE)
        {
            System.exit(0);
        }
    }

    public StateBasedGame getStateBasedGame()
    {
        return stateBasedGame;
    }

    public void setStateBasedGame(StateBasedGame stateBasedGame)
    {
        this.stateBasedGame = stateBasedGame;
    }
    
    public Bag<GameSubState> getSubStates()
    {
        return subStates;
    }

    public void setSubStates(Bag<GameSubState> subStates)
    {
        this.subStates = subStates;
    }

    public GameSubState getCurrentState()
    {
        return currentState;
    }

    public void setCurrentState(GameSubState currentState)
    {
        this.currentState = currentState;
    }
    
    public Scene getScene()
    {
        return scene;
    }

    public Game getGame()
    {
        return game;
    }

    public Camera getCamera()
    {
        return camera;
    }

    public ActorGroup getMenus()
    {
        return menus;
    }
}

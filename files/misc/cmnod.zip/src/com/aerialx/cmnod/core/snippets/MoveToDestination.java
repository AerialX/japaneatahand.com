/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.aerialx.cmnod.core.snippets;

import com.aerialx.cmnod.core.util.Transition;
import com.aerialx.util.Point;
import com.slickset.Actor;
import com.slickset.BaseObject;
import com.slickset.Snippet;
import java.util.ArrayList;
import org.newdawn.slick.state.StateBasedGame;

/**
 * MoveToDestination is a snippet that allows an actor to move with a specified transition
 * @author Aaron Lindsay
 */
public class MoveToDestination extends Snippet {
    
    protected Point previousPosition;
    protected ArrayList<Point> destinations;
    protected Transition transition;
    protected float percentX;
    protected float percentY;
    protected float speed;
    
    public MoveToDestination(Actor parent, Transition transition, float speed)
    {
        super(parent);
        
        this.transition = transition;
        this.speed = speed;
        
        this.destinations = new ArrayList<Point>();
        this.previousPosition = new Point(0, 0);
        this.percentX = 0;
        this.percentY = 0;
    }

    public void start()
    {
    }

    public void update(StateBasedGame game, int delta)
    {
        if (destinations.size() > 0)
        {
            BaseObject parent = getParent();

            Actor actor = (Actor)parent;

            Point destination = destinations.get(0);

            percentX += (float)delta * speed;
            percentY += (float)delta * speed;
            
            if (percentX > 1)
                percentX = 1;
            if (percentY > 1)
                percentY = 1;
            
            actor.setX(transition.getValue(previousPosition.getX(), destination.getX(), percentX));
            actor.setY(transition.getValue(previousPosition.getY(), destination.getY(), percentY));
            
            if (percentX == 1 && percentY == 1)
            {
                setPreviousPosition(destination);
                destinations.remove(0);
            }
        }
    }

    public Point getPreviousPosition()
    {
        return previousPosition;
    }

    public void setPreviousPosition(Point previousPosition)
    {
        this.previousPosition = previousPosition;
        
        percentX = 0;
        percentY = 0;
    }

    public ArrayList<Point> getDestinations()
    {
        return destinations;
    }
}
java -Djava.library.path="." -cp build/classes:dist/lib/* com.aerialx.cmnod.FireEmblem

                                  Supersonic Wii
                                  Winter Edition
                               www.supersonicwii.com
January 18th, 2009

================
  Introduction
================

Well, if anyone's been following my work, this release has been a long-time coming. I've
been working on it since back in July, and I guess it's just been delayed for so long
since this is a one-manned project and I don't have a lot of free time, and partly because
I'm a perfectionist when it comes to this kind of thing. Whatever the case, here it is,
finally. My first real contribution to the Wii Homebrew scene :D

What is it?
-----------

Supersonic Wii: Winter Edition, released specially for the drunkencoders.com Winter
competition, is a game based upon the gameplay of the AmplituDS homebrew game for the
Nintendo DS, in turn based on the game Amplitude for the Playstation 2 by Harmonix (the
creators of the Guitar Hero and Rock Band franchises). It is a homebrew Wii game made in
my spare time (unlicensed by Nintendo), in the hopes that others will find it as fun as I
do.

Supersonic Wii is a music rhythm game where the player needs to hit buttons in sync with
the music being played. Called "space button Guitar Hero" by some, you play one part of
the song at a time (focus on one instrument at a time, for example drums) until you've
played it enough to continue on and try another. The sound for each instrument track only
plays if you are successful at playing the pattern.


================
  Installation
================

Since this isn't a licenced game for the Nintendo Wii, first you'll need the Homebrew
Channel installed. This requires that you use The Legend of Zelda: Twilight Princess
disc to install it (it's only required once, so if you don't own it, go rent or borrow
it for a day, you literally only need it for 5 minutes). You can also install it if you
have a modchip and haven't updated your Wii yet. For instructions to install the Homebrew
Channel, see http://www.wiibrew.org/wiki/Homebrew_Channel#Installation

Once the Homebrew Channel is installed (or you already had it installed), the installation
of Supersonic Wii itself is simple. Just extract your downloaded archive into the root
of your SD (or SDHC) card, so that the "apps" and "data" folders are merged to the card.
You don't need this README file there, of course, so you can ignore/delete it.

And that's it! Just extract this download to an SD card and you're ready to play.
Start up the Homebrew Channel and pick Supersonic Wii from the menu.


============
  Gameplay
============

Once you've chosen a stage to play, you will control a ship flying over note tracks. You
are able to move left and right to different lanes, and you need to hit the notes on it
until the track disappears. Once it does you should move on (left or right) to another
track and complete its notes. The more patterns you complete in a row, the higher your
multiplier gets and you score more points. The goal is to get as high a score as you can
on a stage.

Now, the trick to the game is actually hitting the notes. There are three possible notes
on a track: left, middle, and right. You have three laser buttons to hit the notes; read
below to find out the different control schemes available to you. It's important to choose
the best control scheme you're comfortable with. Previous Guitar Hero players may find the
Guitar Hero controller the most comfortable, but as you reach the harder difficulties,
Brutal and Insane, it may be necessary to use the more efficient control schemes, such as
the Nunchuk Insanity scheme.


============
  Controls
============

The control scheme automatically changes depending on the extension controller you have
plugged in. Each controller has variations that can be set in the Options menu. Always
use the first Wiimote (the one with the first LED lit up) to play the game and navigate
menus.

Note that in all control schemes, the Home button will return you to the loader (in most
cases the Homebrew Channel), and the Plus (+) button will allow you to quit a stage while
part-way through.

Horizontal Wiimote
------------------
This is the default control scheme when you don't have any extension controllers plugged
in. Hold the Wiimote horizontally so that you can press the DPad with your left thumb
(and keep a finger on B), and 1/2 with your right thumb (and keep a finger on B).

Button Mapping
Menu Select:  2, A
Menu Back:    1, B

Left Laser:   A
Middle Laser: 1
Right Laser:  2

Upside-Down Wiimote
-------------------
This control scheme may seem awkward, but it lets you use you use your other fingers
to press the buttons, instead of having to worry about your sluggish thumb speed. This
is only recommended for experienced players.
You hold the Wiimote much like in the horizontal setting, except instead you turn it
upside-down so that you can have a left finger on the DPad and nother on the A button,
and two fingers on your right hand can rest on the 1 and 2 buttons.

Button Mapping
Menu Select:  2, A
Menu Back:    1, B

Left Laser:   A
Middle Laser: 1
Right Laser:  2

Normal Nunchuk
--------------
This is the default control scheme when you plug in a Nunchuk into your Wiimote. You have
the option of specifying whether you want to hold the Nunchuk in your left hand or your
right hand. The controls default to the Nunchuk in your left hand; if you change it to
your right, the buttons for the Left and Right Laser mappings are reversed.

Button Mapping
Menu Select:  A
Menu Back:    B

Left Laser:   C
Middle Laser: A
Right Laser:  B

Nunchuk Insanity
----------------
I owe this control scheme to Devil_Spawn. It attempts to emulate the experience of the
controls for the original Amplitude game, and works very well for Insane players once you
get used to the wacky way you're forced to hold the Wiimote. If you wish to use this, just
go to the Options menu and change the Nunchuk Style to Insanity.
Hold the Nunchuk in one hand like normal (the default is having the Nunchuk in your left
hand, but you can chance it in the Options menu; if you do, the buttons for the Left and
Right Laser mappings are reversed). In your other hand, grip the Wiimote at the bottom
so that you can rest your index and middle fingers on the 1 and 2 buttons.

Button Mapping
Menu Select:  2, B
Menu Back:    1, A

Left Laser:   C
Middle Laser: 2
Right Laser:  1

Guitar Hero 3 Guitar
--------------------
For those used to Guitar Hero or Rock Band, you may use your Guitar Hero 3 Les Paul guitar
to control the game. Simply hold it like you normally would and forget about the Orange
button and your stretch/shift techniques; it'll take a lot of discipline just to get the
game right with the first three fret buttons. The strum bar can be used to navigate up and
down the menus, and is used in-game to move your ship left and right. In the menu you'll
have to use the Yellow and Blue buttons as left and right if you need to change settings.

Button Mapping
Menu Select:  Green
Menu Back:    Red

Left Laser:   Green
Middle Laser: Red
Right Laser:  Yellow


==========
  Source
==========

Maybe some of you noticed, but there is no source code release of Supersonic Wii: Winter
Edition. Why? Simply put, it's not ready. A lot of bits aren't finished, and some of it
is a mess. This is only a preview release after all. I'll likely release the source with
the real first release of Supersonic Wii.

If anyone really wants to see how I did certain things, you're free to contact me (see the
section at the end for contact details) and I'll be happy to help you, show you what I
did and/or share some ported libraries.


==========
  Thanks
==========

Well, here's the initial release and I already have a number of people to thank. Soo...

First off, thanks to Sander Stolk (Dark Knight ez). Without him this project
wouldn't exist, and I wouldn't have even heard of Amplitude. It's because of the countless
hours I spent playing his AmplituDS that I wanted to make this project for the Wii, so
here we are. He also contributed a number of skyboxes and stage charts.

Thanks to Kevin Dodge (kevind23) for designing the whole interface for Supersonic Wii. My
attempts at anything graphics-related are pathetic, so he's the whole reason that the game
looks as good as it does.

Thanks to LDAsh for allowing me to use his excellent space ship model, and also for
providing me with a great skybox.

Thanks to tssf who made a number of musical contributions, including the Synthetic
Nightmare song as well as creating the Turrican theme remix (under Chris Huelsbeck's
permission to remix the theme under the condition that it not be sold).
The game's loading image was made by Axeraider70.

I'd also like to thank my testers for their support and advice throughout the duration of
this project. I managed to throw together a difficult stage for Devil_Spawn's 1337
Amplitude skills, and Roy911.... uh... got to play it before everyone else :P

The creators of all the libraries I used to create this project deserve thanks too, making
different aspects of the game possible. MikIT is the reason I can play the music files.
libsnd is the reason that you can hear said music files. Boost just saved a lot of time
in general and made the experience less hell :). libwiisprite made the HUD and GUI of
the game possible. Freetype helped me use proper fonts, fitted into libwiisprite by my
own custom setup (dubbed libfreesprite) and a bit of example code by DragonMinded. libpng
and pngu allowed me to use the best image format in the world, while libxml2 and libxml++
were used to allow me to easily store configuration and save files on the SD card.
Dunno why I listed everything like that, but I'm thankful to all library creators out
there that made this game possible. Finally, libfat, libogc, and devkitPPC all allowed me
to make this game for everyone's favourite gaming platform, the Nintendo Wii.

Finally, thanks to whoever downloads and plays this game :)


===========
  Contact
===========

Any feedback (bugs, suggestions, etc.) is welcome and can be directed to my email address
aaron@supersonicwii.com

You can also find me on IRC under the nickname AerialX in #wiidev on the EFNet network.


Enjoy!
 - Aaron

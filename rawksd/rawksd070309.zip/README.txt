Visit http://wadder.net/rawksd for instructions.

Brought to you by Aaron "AerialX", tueidj, and Mrkinator

Special Thanks to nanook for Queen Bee.
#include "Stream.h"
#include <stdio.h>

extern void* __getsmem(size_t size);

#define memalign(a, b) \
	__getsmem(b);
#define free(a) ;

FileStream::FileStream(FILE* fid)
{
	Fid = fid;
	close = false;
	position = 0;
}

FileStream::FileStream(char* path)
{
	Fid = fopen(path, "r+b");
	if (Fid == NULL) {
		Fid = fopen(path, "w");
		fclose(Fid);
		Fid = fopen(path, "r+b");
	}

	close = true;
	position = 0;
}

void FileStream::Write(u8* data, int size)
{
	fwrite(data, 1, size, Fid);

	position += size;
}

int FileStream::Read(u8* data, int size)
{
	int ret = fread(data, 1, size, Fid);
	
	position += ret;

	return ret;
}

void FileStream::Seek(int pos)
{
	fseek(Fid, pos, SEEK_SET);

	position = pos;
}

int FileStream::GetPosition()
{
	return position;
}

void FileStream::Close()
{
	if (close)
		fclose(Fid);
}

MemoryStream::MemoryStream(u8* mem)
{
	Memory = mem;
	position = 0;
}
void MemoryStream::Write(u8* data, int size)
{
	memcpy(Memory + position, data, size);
	position += size;
}
int MemoryStream::Read(u8* data, int size)
{
	memcpy(data, Memory + position, size);
	position += size;
	return size;
}
void MemoryStream::Seek(int pos)
{
	position = pos;
}
int MemoryStream::GetPosition()
{
	return position;
}

IsfsStream::IsfsStream(int fid)
{
	Fid = fid;
	close = false;
	position = 0;
}
IsfsStream::IsfsStream(char* path)
{
	Fid = ISFS_Open(path, ISFS_OPEN_RW);
	close = true;
	position = 0;
}

extern u32 __RoundUp(u32 p, int round);

void IsfsStream::Write(u8* data, int size)
{
	//if (__RoundUp(data, 4) != data) { // Align pointers
		static u8 buffer[0x200] ATTRIBUTE_ALIGN(32);
		for (int i = 0; i < size; i += 0x200) {
			int written = MIN(0x200, size - i);
			memcpy(buffer, data + i, written);
			ISFS_Write(Fid, buffer, written);
		}
	//} else
	//	ISFS_Write(Fid, data, size);

	position += size;
}
int IsfsStream::Read(u8* data, int size)
{
	int ret = 0;

	//if (__RoundUp(data, 4) != data) { // Align pointers
		static u8 buffer[0x200] ATTRIBUTE_ALIGN(32);
		for (int i = 0; i < size; i += 0x200) {
			int read = MIN(0x200, size - i);
			read = ISFS_Read(Fid, buffer, read);
			if (read <= 0)
				break;
			ret += read;
			memcpy(data + i, buffer, read);
		}
	//} else
	//	ret = ISFS_Read(Fid, data, size);
	
	position += ret;

	return ret;
}
void IsfsStream::Seek(int pos)
{
	ISFS_Seek(Fid, pos, SEEK_SET);

	position = pos;
}
void IsfsStream::Close()
{
	if (close)
		ISFS_Close(Fid);
}
int IsfsStream::GetPosition()
{
	return position;
}

ChunkedDtbStream::ChunkedDtbStream(Stream* stream)
{
	Mode = ChunkedMode::Chunk;
	Base = stream;
	u32 i;
	u32 j;

	Base->Seek(4);
	static u8 data[4] ATTRIBUTE_ALIGN(32);
	Base->Read(data, 4);
	Key = le32(data);

	ChunkMap[0] = -8;
	static u8 buffer[ChunkSize] ATTRIBUTE_ALIGN(32);
	for (i = 1; i <= Chunks; i++) {
		s32 pos;
		Base->Seek((i - 1) * ChunkSize);
		Base->Read(buffer, ChunkSize);
		for (pos = ChunkSize; pos > 0; pos--) {
			if (buffer[pos - 1] != 0)
				break;
		}
		ChunkMap[i] = ChunkMap[i - 1] + pos;
	}

	Length = ChunkMap[Chunks];

	for (i = 0; i < Length; i += SeedLength) {
		Seeds[i / SeedLength] = Key;
		for (j = 0; j < SeedLength; j++)
			Key = XorKey(Key);
	}

	Offset = 0;
	Key = Seeds[0];
	Base->Seek(8);
}

u32 ChunkedDtbStream::GetChunk(u32 pos)
{
	u32 chunk = 0;
	while (ChunkMap[chunk + 1] < pos)
		chunk++;

	return chunk;
}

void ChunkedDtbStream::_Read(u8* buffer, u32 count)
{
	Base->Read(buffer, count);
	for (int i = 0; i < count; i++)
	{
		Key = XorKey(Key);
		buffer[i] ^= Key;
	}
	Offset += count;
}

void ChunkedDtbStream::_Write(u8* buffer, u32 count)
{
	u8* buf = (u8*)memalign(32, count);
	
	for (int i = 0; i < count; i++)
	{
		Key = XorKey(Key);
		buf[i] = (u8)(buffer[i] ^ Key);
	}
	Base->Write(buf, count);

	free(buf);
	
	Offset += count;
}

void ChunkedDtbStream::Write(u8* data, int size)
{
	u8 zero = 0;
	switch (Mode) {
		case ChunkedMode::Chunk: {
				u32 start_chunk;
				u32 end_pos = Offset + size;
				if (size == 0)
					return;

				start_chunk = GetChunk(Offset);
				if (end_pos > (start_chunk + 1) * ChunkSize) {
					u32 front = (start_chunk + 1) * ChunkSize - Base->GetPosition();
					for (u32 j = 0; j < front; j++)
						Base->Write(&zero, 1);
					// fseek(f_in, (start_chunk + 1)*CHUNK_SIZE, SEEK_SET); // Should already be there; if not we're fucked
				}
				_Write(data, size);
				break;
			}
		case ChunkedMode::Game: {
				//uint chunk = GetChunk(Offset);
				u32 diff = ChunkSize - (Base->GetPosition() % ChunkSize);
				if (diff < size) {
					for (u32 j = 0; j < diff; j++)
						Base->Write(&zero, 1);
					//ChunkMap[chunk + 1] = (int)Offset;
					// TODO: Change the value of all ChunkMap entries after chunk + 1
				}

				_Write(data, size);
				break;
			}
	}
}

int ChunkedDtbStream::Read(u8* data, int size)
{
	switch (Mode) {
		case ChunkedMode::Chunk: {
				s32 i;
				u32 start_chunk;
				u32 end_chunk;
				u32 end_pos = Offset + size;
				if (size == 0)
					return 0;
				if (end_pos > Length) {
					size = Length - Offset;
					end_pos = Length;
				}

				start_chunk = GetChunk(Offset);
				end_chunk = GetChunk(end_pos);
				i = 0;
				while (start_chunk != end_chunk) {
					start_chunk++;
					u32 front = ChunkMap[start_chunk] - Offset;
					_Read(data + i, front);
					i += front;
					Base->Seek(start_chunk * ChunkSize);
				}
				_Read(data + i, size - i);
				return size;
			}
		case ChunkedMode::Game: {
				if (ChunkSize - (Base->GetPosition() % ChunkSize) < size)
					Base->Seek((Base->GetPosition() / ChunkSize + 1) * ChunkSize);

				_Read(data, size);

				return size;
			}
		default:
			return -1;
	}
}

void ChunkedDtbStream::Seek(int value)
{
	u32 chunk;
	if (value == Offset)
		return;
	if (value > Length)
		return;

	chunk = GetChunk(value);

	// set file pointer position
	Base->Seek((chunk * ChunkSize) + value - ChunkMap[chunk]);

	// set key
	Key = Seeds[value / SeedLength];
	for (int i = 0; i < (value % SeedLength); i++)
		Key = XorKey(Key);

	Offset = value;
}

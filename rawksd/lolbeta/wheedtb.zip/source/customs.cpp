int __spos = 0;

#include <vector>
using std::vector;

#include "DTB.h"
#include "Stream.h"

void* __getsmem(size_t size)
{
	__spos += size;

	if (__spos >= SAVESIZE) {
		printf("Oooh shit.\n");
	}

	return save + __spos - size;
}

int FindInBuffer(u8* buffer, int bufferlength, u8* pattern, int patternlength)
{
	for (int i = 0; i < bufferlength - patternlength; i++) {
		bool flag = true;
		for (int j = 0; j < patternlength; j++)
			if (buffer[i + j] != pattern[j]) {
				flag = false;
				break;
			}
		if (flag)
			return i;
	}

	return -1;
}

bool UpdateSave()
{
	__spos = 0;

	IsfsStream s("/title/00010000/535a4145/data/rockbnd2.dat");
	ChunkedDtbStream dtb(&s);

	dtb.Mode = ChunkedMode::Chunk;

	int read = dtb.Read(save, dtb.Length);

	u8 thekillwiipattern[] = { 0x05, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x6E, 0x61, 0x6D, 0x65, 0x12, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x54, 0x68, 0x65, 0x20, 0x4B, 0x69, 0x6C, 0x6C };
	int dtbheaderpos = FindInBuffer(save, read, thekillwiipattern, 0x1C) - 0x30 + 3;

	Node root;
	static u8 data[64] ATTRIBUTE_ALIGN(32);
	if (dtbheaderpos < 0) {
		MemoryStream m((u8*)thekill_dat);
		m.Read(data, 1);
		if (data[0] != 1)
			return false;
		root.Read(&m, 0xFFFFFFFF);
		m.Close();
		dtbheaderpos = dtb.Length - 1;
	} else {
		dtb.Seek(dtbheaderpos);
		dtb.Mode = ChunkedMode::Game;
		dtb.Read(data, 1);
		if (data[0] != 1)
			return false;
		root.Read(&dtb, 0xFFFFFFFF);
	}

	dtb.Mode = ChunkedMode::Game;

	string customdir = string("sd:/rawk/rb2/customs");
	DIR_ITER* dir = diropen(customdir.c_str());
	if (dir == NULL) {
		printf("Customs directory does not exist.\n");
		return false;
	}

	vector<Node> nodes;

	u32 size = le16(root.ChildrenData);

	for (int i = 0; i < size; i++) { // Re-adding real DLC
		u32 tsize = le32(root.Children[i].Children[0].Data);
		if (tsize > 3 && !memcmp((const void*)root.Children[i].Children[0].SecondaryData, (const void*)"rwk", 3))
			continue;
		nodes.push_back(root.Children[i]);
	}

	struct stat st;
	char filename[MAXPATHLEN];
	while (dirnext(dir, filename, &st) == 0) { // Now customs
		if (filename[0] != '.' && (st.st_mode & S_IFDIR)) {
			FileStream fs((char*)(customdir + "/" + filename + "/data").c_str());
			if (fs.Fid == NULL)
				continue;
			fs.Read(data, 1);
			if (data[0] != 1)
				return false; // Not a valid DTB
			Node subnode;
			subnode.Read(&fs, 0xFFFFFFFF);
			subnode.Type = 0x00000010;
			subnode.RealDLC = false;

			fs.Close();

			// God...damn. Add "rwk" prefix
			Node* child = subnode.Children;
			if (child->Type != 0x00000005)
				return false; // WTF IT NEEDS TO BE A STRING
			size = le32(child->Data);
			size = MIN(32, size + 3);
			le32_(size, child->Data);
			u8* newdata = (u8*)__getsmem(size);
			u8* odata = child->SecondaryData;
			memcpy(newdata, "rwk", 3);
			memcpy(newdata + 3, odata, size - 3);
			child->SecondaryData = newdata;

			nodes.push_back(subnode);
		}
	}

	root.Children = (Node*)__getsmem(sizeof(Node) * nodes.size());
	for (int i = 0; i < nodes.size(); i++)
		root.Children[i] = nodes[i];

	le16_(nodes.size(), root.ChildrenData);

	dtb.Seek(dtbheaderpos);
	root.Write(&dtb);

	dtb.Close();
	s.Close();

	return true;
}

extern const u8		thekill_dat[];
extern const u32	thekill_dat_size;

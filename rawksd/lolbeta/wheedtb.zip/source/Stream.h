#include "Util.h"

class Stream
{
public:
	virtual void Write(u8* data, int size) = 0;
	virtual int Read(u8* data, int size) = 0;
	virtual void Seek(int pos) = 0;
	virtual void Close() = 0;
	virtual int GetPosition() { return 0; }
};

class FileStream : public Stream
{
private:
	bool close;
	int position;
public:
	FILE* Fid;
	FileStream(FILE* fid);
	FileStream(char* path);

	void Write(u8* data, int size);
	int Read(u8* data, int size);
	void Seek(int pos);
	void Close();

	int GetPosition();
};

class MemoryStream : public Stream
{
private:
	u8* Memory;
	int position;
public:
	MemoryStream(u8* mem);

	void Write(u8* data, int size);
	int Read(u8* data, int size);
	void Seek(int pos);
	void Close() { }

	int GetPosition();
};

class IsfsStream : public Stream
{
private:
	int Fid;
	bool close;
	int position;
public:
	IsfsStream(int fid);
	IsfsStream(char* path);

	void Write(u8* data, int size);
	int Read(u8* data, int size);
	void Seek(int pos);
	void Close();

	int GetPosition();
};

namespace ChunkedMode
{
	enum Enum
	{
		Chunk = 0,
		Game = 1
	};
}

class ChunkedDtbStream : public Stream
{
private:
	static const s32 SaveSize = 7340032;
	static const s32 ChunkSize = 0x40000;
	static const s32 Chunks = SaveSize / ChunkSize;
	static const s32 SeedLength = 65536;
	static const s32 SeedIndexCount = SaveSize / SeedLength;

	Stream* Base;

	u32 Offset;
	u32 Key;
	s32 ChunkMap[Chunks + 1];
	u32 Seeds[SeedIndexCount];

public:
	u32 Length;

	ChunkedDtbStream(Stream* stream);

	void Write(u8* data, int size);
	int Read(u8* data, int size);
	void Seek(int pos);
	void Close() { }

	u32 GetChunk(u32 pos);
	void _Read(u8* buffer, u32 count);
	void _Write(u8* buffer, u32 count);

	static u32 XorKey(u32 data)
	{
		int val1 = (data / 0x1F31D) * 0xB14;
		int val2 = (data - ((data / 0x1F31D) * 0x1F31D)) * 0x41A7;
		val2 = val2 - val1;
		if(val2 <= 0)
			val2 += 0x7FFFFFFF;
		return val2;
	}

	ChunkedMode::Enum Mode;
};

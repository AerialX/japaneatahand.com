#include "DTB.h"
#include "Stream.h"

#include <string.h>

#define printf DebugPrintf

extern void* __getsmem(size_t size);

#define alloc(b) \
	__getsmem(b);

Node::Node()
{
	Construct();
}

void Node::Construct()
{
	Data = (u8*)alloc(4);
}

void Node::Write(Stream* stream)
{
	static u8 data[4] ATTRIBUTE_ALIGN(32);
	if (Type == 0xFFFFFFFF) {
		data[0] = 0x01;
		stream->Write(data, 1);
	} else {
		le32_(Type, data);
		stream->Write(data, 4);
	}

	u32 size = 0;

	switch (Type) {
		case 0x00000010:
		case 0x00000011:
		case 0x00000013:
		case 0xFFFFFFFF:
			stream->Write(ChildrenData, 2);
			stream->Write(Data, 2);
			stream->Write(Data + 2, 2);

			size = le16(ChildrenData);
			break;
		default:
			stream->Write(Data, 4);
			size = le32(Data);
	}

	switch (Type) {
		case 0x00000002:
		case 0x00000005:
		case 0x00000007:
		case 0x00000012:
		case 0x00000020:
		case 0x00000021:
		case 0x00000022:
		case 0x00000023:
			// lol
			if (size > 6 && !RealDLC && !strncasecmp("dlc/sZ", (const char*)SecondaryData, 6))
				SecondaryData[4] = 'c';

			stream->Write(SecondaryData, size);
			break;
		case 0x00000010:
		case 0x00000011:
		case 0x00000013:
		case 0xFFFFFFFF:
			for (u32 i = 0; i < size; i++) {
				Children[i].Write(stream);
			}
			break;
	}
}

void Node::Read(Stream* stream, u32 type)
{
	RealDLC = true;

	Type = type;

	u32 size = 0;

	switch (Type) {
		case 0x00000010:
		case 0x00000011:
		case 0x00000013:
		case 0xFFFFFFFF:
			ChildrenData = (u8*)alloc(2);
			stream->Read(ChildrenData, 2);
			size = le16(ChildrenData);

			stream->Read(Data, 2);
			stream->Read(Data + 2, 2);
			break;
		default:
			stream->Read(Data, 4);
			size = le32(Data);
	}

	switch (Type) {
		case 0x00000002:
		case 0x00000005:
		case 0x00000007:
		case 0x00000012:
		case 0x00000020:
		case 0x00000021:
		case 0x00000022:
		case 0x00000023:
			SecondaryData = (u8*)alloc(size);
			stream->Read(SecondaryData, size);
			break;
		case 0x00000010:
		case 0x00000011:
		case 0x00000013:
		case 0xFFFFFFFF:
			static u8 data[4] ATTRIBUTE_ALIGN(32);
			Children = (Node*)alloc(sizeof(Node) * size);
			for (u32 i = 0; i < size; i++) {
				stream->Read(data, 4);
				Children[i].Construct();
				Children[i].RealDLC = RealDLC;
				Children[i].Read(stream, le32(data));
			}
			break;
	}
}

static void le32_(u32 value, u8* data)
{
	data[0] = (u8)value;
	data[1] = (u8)(value >> 8);
	data[2] = (u8)(value >> 16);
	data[3] = (u8)(value >> 24);
}

static void le16_(u16 value, u8* data)
{
	data[0] = (u8)value;
	data[1] = (u8)(value >> 8);
}

static u16 le16(u8* data)
{
	return (u16)(data[0] | (data[1] << 8));
}

static u32 le32(u8* data)
{
	return (u32)le16(data) | ((u32)le16(data + 2) << 16);
}
#include "Util.h"

class Stream;

class Node
{
public:
	Node();

	void Construct();

	u32 Type;
	u8* Data;
	u8* SecondaryData;
	u8* ChildrenData;
	Node* Children;

	bool RealDLC;

	void Write(Stream* stream);
	void Read(Stream* stream, u32 type);
};
